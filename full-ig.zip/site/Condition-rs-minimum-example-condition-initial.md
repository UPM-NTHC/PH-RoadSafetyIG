# Minimum Data Set Initial Impression - DRAFT PH Road Safety Implementation Guide v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Minimum Data Set Initial Impression**

## Example Condition: Minimum Data Set Initial Impression

Profile: [RS Condition — Initial Impression](StructureDefinition-rs-condition-initial-impression.md)

**clinicalStatus**: Active

**verificationStatus**: Provisional

**code**: Injury of multiple body regions (disorder)

**subject**: [Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-minimum-example-patient.md)

**encounter**: [Encounter: identifier = http://doh.incident.system/#INC-2025-0102,http://doh.hospitalno.system/#HCN-2025-1120; status = finished; class = ER (LOINC#LA10268-3); period = 2025-11-08 14:30:00+0800 --> 2025-11-08 16:45:00+0800](Encounter-rs-minimum-example-encounter.md)

**onset**: 2025-11-08 14:30:00+0800



## Resource Content

```json
{
  "resourceType" : "Condition",
  "id" : "rs-minimum-example-condition-initial",
  "meta" : {
    "profile" : [
      "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-condition-initial-impression"
    ]
  },
  "clinicalStatus" : {
    "coding" : [
      {
        "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
        "code" : "active"
      }
    ]
  },
  "verificationStatus" : {
    "coding" : [
      {
        "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
        "code" : "provisional"
      }
    ]
  },
  "code" : {
    "coding" : [
      {
        "system" : "http://snomed.info/sct",
        "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
        "code" : "125605004",
        "display" : "Injury of multiple body regions (disorder)"
      }
    ]
  },
  "subject" : {
    "reference" : "Patient/rs-minimum-example-patient"
  },
  "encounter" : {
    "reference" : "Encounter/rs-minimum-example-encounter"
  },
  "onsetDateTime" : "2025-11-08T14:30:00+08:00"
}

```
