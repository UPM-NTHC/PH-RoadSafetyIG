# Vehicle Types - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Vehicle Types**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-vehicle-types.xml.md) 
*  [JSON](CodeSystem-vehicle-types.json.md) 
*  [TTL](CodeSystem-vehicle-types.ttl.md) 

## CodeSystem: Vehicle Types (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/CodeSystem/vehicle-types | *Version*:0.1.0 |
| Draft as of 2025-10-08 | *Computable Name*:VehicleTypeCS |

 
A code system for different types of vehicles used in road safety encounters. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [VehicleTypeVS](ValueSet-vs-rs-vehicle-type.md)

This case-sensitive code system `https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/CodeSystem/vehicle-types` defines the following codes:

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

