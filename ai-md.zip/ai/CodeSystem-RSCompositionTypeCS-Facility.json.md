# Road Safety Composition Type (Facility) - JSON Representation - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Road Safety Composition Type (Facility)**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/history.html)

*  [Narrative Content](CodeSystem-RSCompositionTypeCS-Facility.md) 
*  [XML](CodeSystem-RSCompositionTypeCS-Facility.xml.md) 
*  [JSON](#) 
*  [TTL](CodeSystem-RSCompositionTypeCS-Facility.ttl.md) 

## : Road Safety Composition Type (Facility) - JSON Representation

| |
| :--- |
| Draft as of 2025-10-06 |

[Raw json](CodeSystem-RSCompositionTypeCS-Facility.json) | [Download](CodeSystem-RSCompositionTypeCS-Facility.json)

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package ph-road-safety-ig#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

