# Composition - Run Report - JSON Representation - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Composition - Run Report**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](StructureDefinition-CompositionRunReport.md) 
*  [Detailed Descriptions](StructureDefinition-CompositionRunReport-definitions.md) 
*  [Mappings](StructureDefinition-CompositionRunReport-mappings.md) 
*  [XML](StructureDefinition-CompositionRunReport.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-CompositionRunReport.profile.ttl.md) 

## Resource Profile: CompositionRunReport - JSON Profile

| |
| :--- |
| Draft as of 2025-10-07 |

JSON representation of the CompositionRunReport resource profile.

[Raw json](StructureDefinition-CompositionRunReport.json) | [Download](StructureDefinition-CompositionRunReport.json)

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

