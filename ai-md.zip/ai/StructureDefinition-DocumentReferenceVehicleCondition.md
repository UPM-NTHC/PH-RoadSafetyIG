# DocumentReference - Vehicle Condition - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DocumentReference - Vehicle Condition**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-DocumentReferenceVehicleCondition-definitions.md) 
*  [Mappings](StructureDefinition-DocumentReferenceVehicleCondition-mappings.md) 
*  [XML](StructureDefinition-DocumentReferenceVehicleCondition.profile.xml.md) 
*  [JSON](StructureDefinition-DocumentReferenceVehicleCondition.profile.json.md) 
*  [TTL](StructureDefinition-DocumentReferenceVehicleCondition.profile.ttl.md) 

## Resource Profile: DocumentReference - Vehicle Condition 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/DocumentReferenceVehicleCondition | *Version*:0.1.0 |
| Draft as of 2025-10-08 | *Computable Name*:DocumentReferenceVehicleCondition |

 
MDS226: Vehicle condition documents; alternative structured observations may exist. 

**Usages:**

* Refer to this Profile: [Composition - Run Report](StructureDefinition-CompositionRunReport.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/example.fhir.ph.roadsafety|current/StructureDefinition/DocumentReferenceVehicleCondition)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

**Summary**

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

**Summary**

 

Other representations of profile: [CSV](StructureDefinition-DocumentReferenceVehicleCondition.csv), [Excel](StructureDefinition-DocumentReferenceVehicleCondition.xlsx), [Schematron](StructureDefinition-DocumentReferenceVehicleCondition.sch) 

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

