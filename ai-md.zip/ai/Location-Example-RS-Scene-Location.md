# Accident Scene Location - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Accident Scene Location**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Narrative Content](#) 
*  [XML](Location-Example-RS-Scene-Location.xml.md) 
*  [JSON](Location-Example-RS-Scene-Location.json.md) 
*  [TTL](Location-Example-RS-Scene-Location.ttl.md) 

## Example Location: Accident Scene Location

Profile: [PH Core Location](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-location.html)

**status**: Active

**name**: Accident Scene - Corner of EDSA and Main St

**mode**: Instance

**address**: Corner of EDSA and Main St, Barangay 123, Quezon City, NCR, Philippines

### Positions

| | | |
| :--- | :--- | :--- |
| - | **Longitude** | **Latitude** |
| * | 121.0345 | 14.6512 |

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

