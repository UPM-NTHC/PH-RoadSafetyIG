# Encounter - Facility - Mappings - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Encounter - Facility**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](StructureDefinition-EncounterFacility.md) 
*  [Detailed Descriptions](StructureDefinition-EncounterFacility-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-EncounterFacility.profile.xml.md) 
*  [JSON](StructureDefinition-EncounterFacility.profile.json.md) 
*  [TTL](StructureDefinition-EncounterFacility.profile.ttl.md) 

## Resource Profile: EncounterFacility - Mappings

| |
| :--- |
| Draft as of 2025-10-07 |

Mappings for the EncounterFacility resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

