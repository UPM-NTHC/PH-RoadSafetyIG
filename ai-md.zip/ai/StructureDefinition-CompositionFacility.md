# Composition - Facility Report - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Composition - Facility Report**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-CompositionFacility-definitions.md) 
*  [Mappings](StructureDefinition-CompositionFacility-mappings.md) 
*  [XML](StructureDefinition-CompositionFacility.profile.xml.md) 
*  [JSON](StructureDefinition-CompositionFacility.profile.json.md) 
*  [TTL](StructureDefinition-CompositionFacility.profile.ttl.md) 

## Resource Profile: Composition - Facility Report 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/CompositionFacility | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:CompositionFacility |

 
Composition for facility/ONEISS navigation, structured into coded sections derived from the Road Safety MDS (ED vitals, conditions, outcome, documents, tasks). Enables IG UIs to present a consistent outline. 

**Usages:**

* Use this Profile: [Facility Bundle (prescribed)](StructureDefinition-FacilityBundle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ph-road-safety-ig|current/StructureDefinition/CompositionFacility)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Composition](http://hl7.org/fhir/R4/composition.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Composition](http://hl7.org/fhir/R4/composition.html) 

**Summary**

Mandatory: 6 elements(6 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [Encounter - Facility(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/EncounterFacility)](StructureDefinition-EncounterFacility.md)
* [Observation - ED Heart Rate(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationEDHeartRate)](StructureDefinition-ObservationEDHeartRate.md)
* [Observation - ED Blood Pressure(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationEDBloodPressure)](StructureDefinition-ObservationEDBloodPressure.md)
* [Condition - Initial Impression(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ConditionInitialImpression)](StructureDefinition-ConditionInitialImpression.md)
* [Condition - ICD-10 Nature of Injury(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ConditionICD10NatureOfInjury)](StructureDefinition-ConditionICD10NatureOfInjury.md)
* [Condition - ICD-10 External Cause(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ConditionICD10ExternalCause)](StructureDefinition-ConditionICD10ExternalCause.md)
* [Observation - Condition of Patient(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationConditionOfPatient)](StructureDefinition-ObservationConditionOfPatient.md)
* [Observation - Status on Arrival(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationStatusOnArrival)](StructureDefinition-ObservationStatusOnArrival.md)
* [Observation - Outcome at Discharge(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationOutcomeAtDischarge)](StructureDefinition-ObservationOutcomeAtDischarge.md)
* [Observation - Mode of Transport to Facility(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationModeOfTransport)](StructureDefinition-ObservationModeOfTransport.md)
* [DocumentReference - ONEISS Facility Report(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/DocumentReferenceFacilityReport)](StructureDefinition-DocumentReferenceFacilityReport.md)
* [Road Safety Task(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/TaskRoadSafety)](StructureDefinition-TaskRoadSafety.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Composition.section

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Composition](http://hl7.org/fhir/R4/composition.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Composition](http://hl7.org/fhir/R4/composition.html) 

**Summary**

Mandatory: 6 elements(6 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [Encounter - Facility(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/EncounterFacility)](StructureDefinition-EncounterFacility.md)
* [Observation - ED Heart Rate(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationEDHeartRate)](StructureDefinition-ObservationEDHeartRate.md)
* [Observation - ED Blood Pressure(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationEDBloodPressure)](StructureDefinition-ObservationEDBloodPressure.md)
* [Condition - Initial Impression(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ConditionInitialImpression)](StructureDefinition-ConditionInitialImpression.md)
* [Condition - ICD-10 Nature of Injury(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ConditionICD10NatureOfInjury)](StructureDefinition-ConditionICD10NatureOfInjury.md)
* [Condition - ICD-10 External Cause(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ConditionICD10ExternalCause)](StructureDefinition-ConditionICD10ExternalCause.md)
* [Observation - Condition of Patient(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationConditionOfPatient)](StructureDefinition-ObservationConditionOfPatient.md)
* [Observation - Status on Arrival(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationStatusOnArrival)](StructureDefinition-ObservationStatusOnArrival.md)
* [Observation - Outcome at Discharge(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationOutcomeAtDischarge)](StructureDefinition-ObservationOutcomeAtDischarge.md)
* [Observation - Mode of Transport to Facility(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationModeOfTransport)](StructureDefinition-ObservationModeOfTransport.md)
* [DocumentReference - ONEISS Facility Report(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/DocumentReferenceFacilityReport)](StructureDefinition-DocumentReferenceFacilityReport.md)
* [Road Safety Task(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/TaskRoadSafety)](StructureDefinition-TaskRoadSafety.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Composition.section

 

Other representations of profile: [CSV](StructureDefinition-CompositionFacility.csv), [Excel](StructureDefinition-CompositionFacility.xlsx), [Schematron](StructureDefinition-CompositionFacility.sch) 

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package ph-road-safety-ig#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

