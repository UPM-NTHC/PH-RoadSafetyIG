# Road Safety Minimum Dataset (MDS) Logical Model - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Road Safety Minimum Dataset (MDS) Logical Model**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-PH-RoadSafetyLogicalModel-definitions.md) 
*  [Mappings](StructureDefinition-PH-RoadSafetyLogicalModel-mappings.md) 
*  [XML](StructureDefinition-PH-RoadSafetyLogicalModel.profile.xml.md) 
*  [JSON](StructureDefinition-PH-RoadSafetyLogicalModel.profile.json.md) 
*  [TTL](StructureDefinition-PH-RoadSafetyLogicalModel.profile.ttl.md) 

## Logical Model: Road Safety Minimum Dataset (MDS) Logical Model 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/PH-RoadSafetyLogicalModel | *Version*:0.1.0 |
| Draft as of 2025-10-07 | *Computable Name*:MDSRoadSafety |

 
Abstract, sectioned logical model for the PH Road Safety MDS covering incident, patient, encounter, clinical, vitals, injuries, evidence/documents, workflow, and finance. Elements mirror the CSV rows; mappings point to target FHIR elements for subsequent profiling. 

**Usages:**

* This Logical Model is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/example.fhir.ph.roadsafety|current/StructureDefinition/PH-RoadSafetyLogicalModel)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(1 nested mandatory element)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(1 nested mandatory element)

 

Other representations of profile: [CSV](StructureDefinition-PH-RoadSafetyLogicalModel.csv), [Excel](StructureDefinition-PH-RoadSafetyLogicalModel.xlsx) 

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

