# DocumentReference - ONEISS Facility Report - TTL Representation - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DocumentReference - ONEISS Facility Report**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/history.html)

*  [Content](StructureDefinition-DocumentReferenceFacilityReport.md) 
*  [Detailed Descriptions](StructureDefinition-DocumentReferenceFacilityReport-definitions.md) 
*  [Mappings](StructureDefinition-DocumentReferenceFacilityReport-mappings.md) 
*  [XML](StructureDefinition-DocumentReferenceFacilityReport.profile.xml.md) 
*  [JSON](StructureDefinition-DocumentReferenceFacilityReport.profile.json.md) 
*  [TTL](#) 

## Resource Profile: DocumentReferenceFacilityReport - TTL Profile

| |
| :--- |
| Draft as of 2025-10-06 |

TTL representation of the DocumentReferenceFacilityReport resource profile.

[Raw ttl](StructureDefinition-DocumentReferenceFacilityReport.ttl) | [Download](StructureDefinition-DocumentReferenceFacilityReport.ttl)

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package ph-road-safety-ig#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

