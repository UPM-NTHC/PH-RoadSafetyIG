# Encounter - Facility - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Encounter - Facility**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-EncounterFacility-definitions.md) 
*  [Mappings](StructureDefinition-EncounterFacility-mappings.md) 
*  [XML](StructureDefinition-EncounterFacility.profile.xml.md) 
*  [JSON](StructureDefinition-EncounterFacility.profile.json.md) 
*  [TTL](StructureDefinition-EncounterFacility.profile.ttl.md) 

## Resource Profile: Encounter - Facility 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/EncounterFacility | *Version*:0.1.0 |
| Draft as of 2025-10-08 | *Computable Name*:EncounterFacility |

 
Encounter profile for facility visits (ONEISS). Contains hospital identifiers and hospitalization.dischargeDisposition. 

**Usages:**

* Use this Profile: [Facility Bundle (prescribed)](StructureDefinition-FacilityBundle.md)
* Refer to this Profile: [Composition - Facility Report](StructureDefinition-CompositionFacility.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/example.fhir.ph.roadsafety|current/StructureDefinition/EncounterFacility)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [PHCoreEncounter](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-encounter.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [PHCoreEncounter](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-encounter.html) 

**Summary**

Mandatory: 0 element(4 nested mandatory elements)
 Must-Support: 6 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Encounter.identifier

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [PHCoreEncounter](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-encounter.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [PHCoreEncounter](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-encounter.html) 

**Summary**

Mandatory: 0 element(4 nested mandatory elements)
 Must-Support: 6 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Encounter.identifier

 

Other representations of profile: [CSV](StructureDefinition-EncounterFacility.csv), [Excel](StructureDefinition-EncounterFacility.xlsx), [Schematron](StructureDefinition-EncounterFacility.sch) 

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

