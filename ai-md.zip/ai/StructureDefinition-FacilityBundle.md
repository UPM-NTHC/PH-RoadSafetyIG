# Facility Bundle (prescribed) - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Facility Bundle (prescribed)**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-FacilityBundle-definitions.md) 
*  [Mappings](StructureDefinition-FacilityBundle-mappings.md) 
*  [XML](StructureDefinition-FacilityBundle.profile.xml.md) 
*  [JSON](StructureDefinition-FacilityBundle.profile.json.md) 
*  [TTL](StructureDefinition-FacilityBundle.profile.ttl.md) 

## Resource Profile: Facility Bundle (prescribed) 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/FacilityBundle | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:FacilityBundle |

 
Bundle profile that prescribes the required slices/resources for facility (ONEISS) submissions. 

**Usages:**

* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ph-road-safety-ig|current/StructureDefinition/FacilityBundle)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

**Summary**

Mandatory: 8 elements(2 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [Composition - Facility Report(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/CompositionFacility)](StructureDefinition-CompositionFacility.md)
* [Encounter - Facility(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/EncounterFacility)](StructureDefinition-EncounterFacility.md)
* [Condition - Initial Impression(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ConditionInitialImpression)](StructureDefinition-ConditionInitialImpression.md)
* [Condition - ICD-10 Nature of Injury(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ConditionICD10NatureOfInjury)](StructureDefinition-ConditionICD10NatureOfInjury.md)
* [Condition - ICD-10 External Cause(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ConditionICD10ExternalCause)](StructureDefinition-ConditionICD10ExternalCause.md)
* [Observation - ED Heart Rate(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationEDHeartRate)](StructureDefinition-ObservationEDHeartRate.md)
* [Observation - ED Blood Pressure(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationEDBloodPressure)](StructureDefinition-ObservationEDBloodPressure.md)
* [Observation - Outcome at Discharge(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationOutcomeAtDischarge)](StructureDefinition-ObservationOutcomeAtDischarge.md)
* [DocumentReference - ONEISS Facility Report(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/DocumentReferenceFacilityReport)](StructureDefinition-DocumentReferenceFacilityReport.md)
* [Road Safety Task(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/TaskRoadSafety)](StructureDefinition-TaskRoadSafety.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Bundle.entry

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

**Summary**

Mandatory: 8 elements(2 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [Composition - Facility Report(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/CompositionFacility)](StructureDefinition-CompositionFacility.md)
* [Encounter - Facility(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/EncounterFacility)](StructureDefinition-EncounterFacility.md)
* [Condition - Initial Impression(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ConditionInitialImpression)](StructureDefinition-ConditionInitialImpression.md)
* [Condition - ICD-10 Nature of Injury(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ConditionICD10NatureOfInjury)](StructureDefinition-ConditionICD10NatureOfInjury.md)
* [Condition - ICD-10 External Cause(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ConditionICD10ExternalCause)](StructureDefinition-ConditionICD10ExternalCause.md)
* [Observation - ED Heart Rate(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationEDHeartRate)](StructureDefinition-ObservationEDHeartRate.md)
* [Observation - ED Blood Pressure(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationEDBloodPressure)](StructureDefinition-ObservationEDBloodPressure.md)
* [Observation - Outcome at Discharge(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationOutcomeAtDischarge)](StructureDefinition-ObservationOutcomeAtDischarge.md)
* [DocumentReference - ONEISS Facility Report(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/DocumentReferenceFacilityReport)](StructureDefinition-DocumentReferenceFacilityReport.md)
* [Road Safety Task(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/TaskRoadSafety)](StructureDefinition-TaskRoadSafety.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Bundle.entry

 

Other representations of profile: [CSV](StructureDefinition-FacilityBundle.csv), [Excel](StructureDefinition-FacilityBundle.xlsx), [Schematron](StructureDefinition-FacilityBundle.sch) 

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package ph-road-safety-ig#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

