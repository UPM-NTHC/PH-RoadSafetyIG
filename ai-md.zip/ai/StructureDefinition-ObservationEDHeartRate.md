# Observation - ED Heart Rate - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Observation - ED Heart Rate**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ObservationEDHeartRate-definitions.md) 
*  [Mappings](StructureDefinition-ObservationEDHeartRate-mappings.md) 
*  [XML](StructureDefinition-ObservationEDHeartRate.profile.xml.md) 
*  [JSON](StructureDefinition-ObservationEDHeartRate.profile.json.md) 
*  [TTL](StructureDefinition-ObservationEDHeartRate.profile.ttl.md) 

## Resource Profile: Observation - ED Heart Rate 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationEDHeartRate | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:ObservationEDHeartRate |

 
ONEISS: Vital sign at facility (HR). 

**Usages:**

* Use this Profile: [Facility Bundle (prescribed)](StructureDefinition-FacilityBundle.md)
* Refer to this Profile: [Composition - Facility Report](StructureDefinition-CompositionFacility.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ph-road-safety-ig|current/StructureDefinition/ObservationEDHeartRate)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [ObservationFacility](StructureDefinition-ObservationFacility.md) 

#### Terminology Bindings

#### Constraints

This structure is derived from [ObservationFacility](StructureDefinition-ObservationFacility.md) 

**Summary**

Mandatory: 2 elements

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [ObservationFacility](StructureDefinition-ObservationFacility.md) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [ObservationFacility](StructureDefinition-ObservationFacility.md) 

**Summary**

Mandatory: 2 elements

 

Other representations of profile: [CSV](StructureDefinition-ObservationEDHeartRate.csv), [Excel](StructureDefinition-ObservationEDHeartRate.xlsx), [Schematron](StructureDefinition-ObservationEDHeartRate.sch) 

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package ph-road-safety-ig#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

