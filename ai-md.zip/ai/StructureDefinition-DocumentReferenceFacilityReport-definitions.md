# DocumentReference - ONEISS Facility Report - Definitions - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DocumentReference - ONEISS Facility Report**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](StructureDefinition-DocumentReferenceFacilityReport.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-DocumentReferenceFacilityReport-mappings.md) 
*  [XML](StructureDefinition-DocumentReferenceFacilityReport.profile.xml.md) 
*  [JSON](StructureDefinition-DocumentReferenceFacilityReport.profile.json.md) 
*  [TTL](StructureDefinition-DocumentReferenceFacilityReport.profile.ttl.md) 

## Resource Profile: DocumentReferenceFacilityReport - Detailed Descriptions

| |
| :--- |
| Draft as of 2025-10-08 |

Definitions for the DocumentReferenceFacilityReport resource profile.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

