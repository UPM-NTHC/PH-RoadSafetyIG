# Road Safety Composition Type (Run) - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Road Safety Composition Type (Run)**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-RSCompositionTypeCS-Run.xml.md) 
*  [JSON](CodeSystem-RSCompositionTypeCS-Run.json.md) 
*  [TTL](CodeSystem-RSCompositionTypeCS-Run.ttl.md) 

## CodeSystem: Road Safety Composition Type (Run) 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/CodeSystem/RSCompositionTypeCS-Run | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:RSCompositionTypeCSRun |

 This Code system is referenced in the content logical definition of the following value sets: 

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

This code system `https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/CodeSystem/RSCompositionTypeCS-Run` defines the following code:

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package ph-road-safety-ig#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

