# Road Safety Task Status Codes - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Road Safety Task Status Codes**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-rs-task-status-cs.xml.md) 
*  [JSON](CodeSystem-rs-task-status-cs.json.md) 
*  [TTL](CodeSystem-rs-task-status-cs.ttl.md) 

## CodeSystem: Road Safety Task Status Codes (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/CodeSystem/rs-task-status-cs | *Version*:0.1.0 |
| Draft as of 2025-10-08 | *Computable Name*:TaskStatus |

 
Custom codes for Task.status specific to Road Safety reporting. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [TaskStatus](ValueSet-rs-task-status.md)

This case-sensitive code system `https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/CodeSystem/rs-task-status-cs` defines the following codes:

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

