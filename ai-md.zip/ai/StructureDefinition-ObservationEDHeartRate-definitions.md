# Observation - ED Heart Rate - Definitions - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Observation - ED Heart Rate**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](StructureDefinition-ObservationEDHeartRate.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-ObservationEDHeartRate-mappings.md) 
*  [XML](StructureDefinition-ObservationEDHeartRate.profile.xml.md) 
*  [JSON](StructureDefinition-ObservationEDHeartRate.profile.json.md) 
*  [TTL](StructureDefinition-ObservationEDHeartRate.profile.ttl.md) 

## Resource Profile: ObservationEDHeartRate - Detailed Descriptions

| |
| :--- |
| Draft as of 2025-10-08 |

Definitions for the ObservationEDHeartRate resource profile.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

