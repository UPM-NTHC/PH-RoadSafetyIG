# Composition - Run Report - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Composition - Run Report**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-CompositionRunReport-definitions.md) 
*  [Mappings](StructureDefinition-CompositionRunReport-mappings.md) 
*  [XML](StructureDefinition-CompositionRunReport.profile.xml.md) 
*  [JSON](StructureDefinition-CompositionRunReport.profile.json.md) 
*  [TTL](StructureDefinition-CompositionRunReport.profile.ttl.md) 

## Resource Profile: Composition - Run Report 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/CompositionRunReport | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:CompositionRunReport |

 
Composition for EMS Run Report navigation, structured into coded sections derived from the Road Safety MDS (triage, vitals, counts, post‑crash, documents, tasks). Enables IG UIs to present a consistent outline. 

**Usages:**

* Use this Profile: [Run Report Bundle (prescribed)](StructureDefinition-RunReportBundle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ph-road-safety-ig|current/StructureDefinition/CompositionRunReport)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Composition](http://hl7.org/fhir/R4/composition.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Composition](http://hl7.org/fhir/R4/composition.html) 

**Summary**

Mandatory: 6 elements(5 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [Encounter - Transport / Run Report(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/EncounterTransportRunReport)](StructureDefinition-EncounterTransportRunReport.md)
* [Location - Incident / Scene(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/LocationIncident)](StructureDefinition-LocationIncident.md)
* [Observation - Triage Category (Scene)(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationTriageCategory)](StructureDefinition-ObservationTriageCategory.md)
* [Observation - Heart Rate(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationHeartRate)](StructureDefinition-ObservationHeartRate.md)
* [Observation - Blood Pressure(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationBloodPressure)](StructureDefinition-ObservationBloodPressure.md)
* [Observation - Extent of Injury(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationExtentOfInjury)](StructureDefinition-ObservationExtentOfInjury.md)
* [Observation - Respiratory Rate(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationRespiratoryRate)](StructureDefinition-ObservationRespiratoryRate.md)
* [Observation - Temperature(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationTemperature)](StructureDefinition-ObservationTemperature.md)
* [Observation - Level of Consciousness(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationLevelOfConsciousness)](StructureDefinition-ObservationLevelOfConsciousness.md)
* [Observation - Pupils(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationPupils)](StructureDefinition-ObservationPupils.md)
* [Observation - Cyanosis(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationCyanosis)](StructureDefinition-ObservationCyanosis.md)
* [Observation - Glasgow Coma Scale(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationGCS)](StructureDefinition-ObservationGCS.md)
* [DocumentReference - ONEISS Run Form(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/DocumentReferenceOneissRunForm)](StructureDefinition-DocumentReferenceOneissRunForm.md)
* [DocumentReference - Cause of Road Crash(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/DocumentReferenceCauseOfCrash)](StructureDefinition-DocumentReferenceCauseOfCrash.md)
* [DocumentReference - Party at Fault(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/DocumentReferencePartyAtFault)](StructureDefinition-DocumentReferencePartyAtFault.md)
* [DocumentReference - Traffic Incident Management(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/DocumentReferenceIncidentManagement)](StructureDefinition-DocumentReferenceIncidentManagement.md)
* [DocumentReference - Road Network Shape Files(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/DocumentReferenceRoadNetworkShapes)](StructureDefinition-DocumentReferenceRoadNetworkShapes.md)
* [DocumentReference - Vehicle Condition(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/DocumentReferenceVehicleCondition)](StructureDefinition-DocumentReferenceVehicleCondition.md)
* [Task - Delay Reporting(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/TaskDelayReporting)](StructureDefinition-TaskDelayReporting.md)
* [Road Safety Task(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/TaskRoadSafety)](StructureDefinition-TaskRoadSafety.md)
* [Observation - Date Received(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationDateReceived)](StructureDefinition-ObservationDateReceived.md)
* [Observation - Time Received(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationTimeReceived)](StructureDefinition-ObservationTimeReceived.md)
* [Observation - Time Enroute(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationTimeEnroute)](StructureDefinition-ObservationTimeEnroute.md)
* [Observation - Time On Scene(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationTimeOnScene)](StructureDefinition-ObservationTimeOnScene.md)
* [Observation - Time Departed Scene(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationTimeDeparted)](StructureDefinition-ObservationTimeDeparted.md)
* [Observation - Time Hospital Arrival(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationTimeHospitalArrival)](StructureDefinition-ObservationTimeHospitalArrival.md)
* [Observation - Time Station Arrival(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationTimeStationArrival)](StructureDefinition-ObservationTimeStationArrival.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Composition.section

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Composition](http://hl7.org/fhir/R4/composition.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Composition](http://hl7.org/fhir/R4/composition.html) 

**Summary**

Mandatory: 6 elements(5 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [Encounter - Transport / Run Report(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/EncounterTransportRunReport)](StructureDefinition-EncounterTransportRunReport.md)
* [Location - Incident / Scene(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/LocationIncident)](StructureDefinition-LocationIncident.md)
* [Observation - Triage Category (Scene)(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationTriageCategory)](StructureDefinition-ObservationTriageCategory.md)
* [Observation - Heart Rate(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationHeartRate)](StructureDefinition-ObservationHeartRate.md)
* [Observation - Blood Pressure(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationBloodPressure)](StructureDefinition-ObservationBloodPressure.md)
* [Observation - Extent of Injury(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationExtentOfInjury)](StructureDefinition-ObservationExtentOfInjury.md)
* [Observation - Respiratory Rate(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationRespiratoryRate)](StructureDefinition-ObservationRespiratoryRate.md)
* [Observation - Temperature(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationTemperature)](StructureDefinition-ObservationTemperature.md)
* [Observation - Level of Consciousness(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationLevelOfConsciousness)](StructureDefinition-ObservationLevelOfConsciousness.md)
* [Observation - Pupils(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationPupils)](StructureDefinition-ObservationPupils.md)
* [Observation - Cyanosis(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationCyanosis)](StructureDefinition-ObservationCyanosis.md)
* [Observation - Glasgow Coma Scale(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationGCS)](StructureDefinition-ObservationGCS.md)
* [DocumentReference - ONEISS Run Form(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/DocumentReferenceOneissRunForm)](StructureDefinition-DocumentReferenceOneissRunForm.md)
* [DocumentReference - Cause of Road Crash(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/DocumentReferenceCauseOfCrash)](StructureDefinition-DocumentReferenceCauseOfCrash.md)
* [DocumentReference - Party at Fault(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/DocumentReferencePartyAtFault)](StructureDefinition-DocumentReferencePartyAtFault.md)
* [DocumentReference - Traffic Incident Management(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/DocumentReferenceIncidentManagement)](StructureDefinition-DocumentReferenceIncidentManagement.md)
* [DocumentReference - Road Network Shape Files(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/DocumentReferenceRoadNetworkShapes)](StructureDefinition-DocumentReferenceRoadNetworkShapes.md)
* [DocumentReference - Vehicle Condition(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/DocumentReferenceVehicleCondition)](StructureDefinition-DocumentReferenceVehicleCondition.md)
* [Task - Delay Reporting(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/TaskDelayReporting)](StructureDefinition-TaskDelayReporting.md)
* [Road Safety Task(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/TaskRoadSafety)](StructureDefinition-TaskRoadSafety.md)
* [Observation - Date Received(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationDateReceived)](StructureDefinition-ObservationDateReceived.md)
* [Observation - Time Received(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationTimeReceived)](StructureDefinition-ObservationTimeReceived.md)
* [Observation - Time Enroute(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationTimeEnroute)](StructureDefinition-ObservationTimeEnroute.md)
* [Observation - Time On Scene(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationTimeOnScene)](StructureDefinition-ObservationTimeOnScene.md)
* [Observation - Time Departed Scene(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationTimeDeparted)](StructureDefinition-ObservationTimeDeparted.md)
* [Observation - Time Hospital Arrival(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationTimeHospitalArrival)](StructureDefinition-ObservationTimeHospitalArrival.md)
* [Observation - Time Station Arrival(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationTimeStationArrival)](StructureDefinition-ObservationTimeStationArrival.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Composition.section

 

Other representations of profile: [CSV](StructureDefinition-CompositionRunReport.csv), [Excel](StructureDefinition-CompositionRunReport.xlsx), [Schematron](StructureDefinition-CompositionRunReport.sch) 

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package ph-road-safety-ig#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

