# Observation - ED Heart Rate - XML Representation - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Observation - ED Heart Rate**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](StructureDefinition-ObservationEDHeartRate.md) 
*  [Detailed Descriptions](StructureDefinition-ObservationEDHeartRate-definitions.md) 
*  [Mappings](StructureDefinition-ObservationEDHeartRate-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-ObservationEDHeartRate.profile.json.md) 
*  [TTL](StructureDefinition-ObservationEDHeartRate.profile.ttl.md) 

## Resource Profile: ObservationEDHeartRate - XML Profile

| |
| :--- |
| Draft as of 2025-10-07 |

XML representation of the ObservationEDHeartRate resource profile.

[Raw xml](StructureDefinition-ObservationEDHeartRate.xml) | [Download](StructureDefinition-ObservationEDHeartRate.xml)

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

