# Hospital Case Number System - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Hospital Case Number System**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Narrative Content](#) 
*  [XML](NamingSystem-hospital-case-no-ns.xml.md) 
*  [JSON](NamingSystem-hospital-case-no-ns.json.md) 
*  [TTL](NamingSystem-hospital-case-no-ns.ttl.md) 

## NamingSystem: Hospital Case Number System 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/NamingSystem/hospital-case-no-ns | *Version*:0.1.0 |
| Active as of 2025-09-22 | *Computable Name*:HospitalCaseNo |

 
Unique identifier assigned to each hospital case. 

### Summary

| | |
| :--- | :--- |
| Defining URL | https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/NamingSystem/hospital-case-no-ns |
| Version | 0.1.0 |
| Name | HospitalCaseNo |
| Status | active |
| Definition | Unique identifier assigned to each hospital case. |
| Publisher | UP Manila - National Institutes of Health - National Telehealth Center |

### Identifiers

* **Type**: URI
  * **Value**: http://yourhospital.org/case-number

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

