# Road Safety Patient Example - With Two Addresses - JSON Representation - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Road Safety Patient Example - With Two Addresses**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Narrative Content](Patient-patient-road-safety-two-addresses.md) 
*  [XML](Patient-patient-road-safety-two-addresses.xml.md) 
*  [JSON](#) 
*  [TTL](Patient-patient-road-safety-two-addresses.ttl.md) 

## : Road Safety Patient Example - With Two Addresses - JSON Representation

[Raw json](Patient-patient-road-safety-two-addresses.json) | [Download](Patient-patient-road-safety-two-addresses.json)

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

