# Facility Bundle (prescribed) - Testing - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Facility Bundle (prescribed)**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](StructureDefinition-FacilityBundle.md) 
*  [Detailed Descriptions](StructureDefinition-FacilityBundle-definitions.md) 
*  [Mappings](StructureDefinition-FacilityBundle-mappings.md) 
*  [XML](StructureDefinition-FacilityBundle.profile.xml.md) 
*  [JSON](StructureDefinition-FacilityBundle.profile.json.md) 
*  [TTL](StructureDefinition-FacilityBundle.profile.ttl.md) 

## Resource Profile: FacilityBundle - Testing

| |
| :--- |
| Draft as of 2025-10-07 |

### Test Plans

**No test plans are currently available for the Profile.**

### Test Scripts

**No test scripts are currently available for the Profile.**

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

