#  - DRAFT PH Road Safety Implementation Guide v0.1.0

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](StructureDefinition-ConditionICD10NatureOfInjury.md) 
*  [Detailed Descriptions](StructureDefinition-ConditionICD10NatureOfInjury-definitions.md) 
*  [Mappings](StructureDefinition-ConditionICD10NatureOfInjury-mappings.md) 
*  [XML](StructureDefinition-ConditionICD10NatureOfInjury.profile.xml.md) 
*  [JSON](StructureDefinition-ConditionICD10NatureOfInjury.profile.json.md) 
*  [TTL](StructureDefinition-ConditionICD10NatureOfInjury.profile.ttl.md) 

## Resource Profile: ConditionICD10NatureOfInjury - Change History

| |
| :--- |
| Draft as of 2025-10-08 |

Changes in the ConditionICD10NatureOfInjury resource profile.

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

