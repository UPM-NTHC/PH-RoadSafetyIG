# Location - Incident / Scene - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - Incident / Scene**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-LocationIncident-definitions.md) 
*  [Mappings](StructureDefinition-LocationIncident-mappings.md) 
*  [XML](StructureDefinition-LocationIncident.profile.xml.md) 
*  [JSON](StructureDefinition-LocationIncident.profile.json.md) 
*  [TTL](StructureDefinition-LocationIncident.profile.ttl.md) 

## Resource Profile: Location - Incident / Scene 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/LocationIncident | *Version*:0.1.0 |
| Draft as of 2025-10-08 | *Computable Name*:LocationIncident |

 
Location profile for crash/incident scene with optional geocoordinates and free-text reference to road network shapefiles or external resources. 

**Usages:**

* Use this Profile: [Run Report Bundle (prescribed)](StructureDefinition-RunReportBundle.md)
* Refer to this Profile: [Composition - Run Report](StructureDefinition-CompositionRunReport.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/example.fhir.ph.roadsafety|current/StructureDefinition/LocationIncident)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [PHCoreLocation](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-location.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [PHCoreLocation](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-location.html) 

**Summary**

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [PHCoreLocation](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-location.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [PHCoreLocation](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-location.html) 

**Summary**

 

Other representations of profile: [CSV](StructureDefinition-LocationIncident.csv), [Excel](StructureDefinition-LocationIncident.xlsx), [Schematron](StructureDefinition-LocationIncident.sch) 

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

