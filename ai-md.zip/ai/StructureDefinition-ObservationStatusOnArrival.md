# Observation - Status on Arrival - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Observation - Status on Arrival**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ObservationStatusOnArrival-definitions.md) 
*  [Mappings](StructureDefinition-ObservationStatusOnArrival-mappings.md) 
*  [XML](StructureDefinition-ObservationStatusOnArrival.profile.xml.md) 
*  [JSON](StructureDefinition-ObservationStatusOnArrival.profile.json.md) 
*  [TTL](StructureDefinition-ObservationStatusOnArrival.profile.ttl.md) 

## Resource Profile: Observation - Status on Arrival 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/ObservationStatusOnArrival | *Version*:0.1.0 |
| Draft as of 2025-10-07 | *Computable Name*:ObservationStatusOnArrival |

 
MDS116/117: Status upon reaching facility (e.g., conscious/unconscious). 

**Usages:**

* Refer to this Profile: [Composition - Facility Report](StructureDefinition-CompositionFacility.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/example.fhir.ph.roadsafety|current/StructureDefinition/ObservationStatusOnArrival)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [ObservationFacility](StructureDefinition-ObservationFacility.md) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [ObservationFacility](StructureDefinition-ObservationFacility.md) 

**Summary**

Mandatory: 2 elements
 Must-Support: 3 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.effective[x]

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [ObservationFacility](StructureDefinition-ObservationFacility.md) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [ObservationFacility](StructureDefinition-ObservationFacility.md) 

**Summary**

Mandatory: 2 elements
 Must-Support: 3 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.effective[x]

 

Other representations of profile: [CSV](StructureDefinition-ObservationStatusOnArrival.csv), [Excel](StructureDefinition-ObservationStatusOnArrival.xlsx), [Schematron](StructureDefinition-ObservationStatusOnArrival.sch) 

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

