# Encounter - Transport / Run Report - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Encounter - Transport / Run Report**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-EncounterTransportRunReport-definitions.md) 
*  [Mappings](StructureDefinition-EncounterTransportRunReport-mappings.md) 
*  [XML](StructureDefinition-EncounterTransportRunReport.profile.xml.md) 
*  [JSON](StructureDefinition-EncounterTransportRunReport.profile.json.md) 
*  [TTL](StructureDefinition-EncounterTransportRunReport.profile.ttl.md) 

## Resource Profile: Encounter - Transport / Run Report 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/EncounterTransportRunReport | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:EncounterTransportRunReport |

 
Encounter for EMS transport/run-report. Incorporates MDS: Incident number (req), Type/class, Received-by participant role. 

**Usages:**

* Use this Profile: [Run Report Bundle (prescribed)](StructureDefinition-RunReportBundle.md)
* Refer to this Profile: [Composition - Run Report](StructureDefinition-CompositionRunReport.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ph-road-safety-ig|current/StructureDefinition/EncounterTransportRunReport)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [PHCoreEncounter](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-encounter.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [PHCoreEncounter](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-encounter.html) 

**Summary**

Mandatory: 1 element(2 nested mandatory elements)
 Must-Support: 4 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Encounter.participant

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [PHCoreEncounter](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-encounter.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [PHCoreEncounter](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-encounter.html) 

**Summary**

Mandatory: 1 element(2 nested mandatory elements)
 Must-Support: 4 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Encounter.participant

 

Other representations of profile: [CSV](StructureDefinition-EncounterTransportRunReport.csv), [Excel](StructureDefinition-EncounterTransportRunReport.xlsx), [Schematron](StructureDefinition-EncounterTransportRunReport.sch) 

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package ph-road-safety-ig#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

