# Observation - Cyanosis - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Observation - Cyanosis**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ObservationCyanosis-definitions.md) 
*  [Mappings](StructureDefinition-ObservationCyanosis-mappings.md) 
*  [XML](StructureDefinition-ObservationCyanosis.profile.xml.md) 
*  [JSON](StructureDefinition-ObservationCyanosis.profile.json.md) 
*  [TTL](StructureDefinition-ObservationCyanosis.profile.ttl.md) 

## Resource Profile: Observation - Cyanosis 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/ObservationCyanosis | *Version*:0.1.0 |
| Draft as of 2025-10-07 | *Computable Name*:ObservationCyanosis |

 
MDS81: Cyanosis presence/type. 

**Usages:**

* Refer to this Profile: [Composition - Run Report](StructureDefinition-CompositionRunReport.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/example.fhir.ph.roadsafety|current/StructureDefinition/ObservationCyanosis)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [ObservationScene](StructureDefinition-ObservationScene.md) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [ObservationScene](StructureDefinition-ObservationScene.md) 

**Summary**

Must-Support: 1 element

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.value[x]

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [ObservationScene](StructureDefinition-ObservationScene.md) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [ObservationScene](StructureDefinition-ObservationScene.md) 

**Summary**

Must-Support: 1 element

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.value[x]

 

Other representations of profile: [CSV](StructureDefinition-ObservationCyanosis.csv), [Excel](StructureDefinition-ObservationCyanosis.xlsx), [Schematron](StructureDefinition-ObservationCyanosis.sch) 

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

