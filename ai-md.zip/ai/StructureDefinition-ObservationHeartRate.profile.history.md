#  - DRAFT PH Road Safety Implementation Guide v0.1.0

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](StructureDefinition-ObservationHeartRate.md) 
*  [Detailed Descriptions](StructureDefinition-ObservationHeartRate-definitions.md) 
*  [Mappings](StructureDefinition-ObservationHeartRate-mappings.md) 
*  [XML](StructureDefinition-ObservationHeartRate.profile.xml.md) 
*  [JSON](StructureDefinition-ObservationHeartRate.profile.json.md) 
*  [TTL](StructureDefinition-ObservationHeartRate.profile.ttl.md) 

## Resource Profile: ObservationHeartRate - Change History

| |
| :--- |
| Draft as of 2025-10-08 |

Changes in the ObservationHeartRate resource profile.

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

