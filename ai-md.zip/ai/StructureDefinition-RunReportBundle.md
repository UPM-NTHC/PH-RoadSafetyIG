# Run Report Bundle (prescribed) - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Run Report Bundle (prescribed)**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-RunReportBundle-definitions.md) 
*  [Mappings](StructureDefinition-RunReportBundle-mappings.md) 
*  [XML](StructureDefinition-RunReportBundle.profile.xml.md) 
*  [JSON](StructureDefinition-RunReportBundle.profile.json.md) 
*  [TTL](StructureDefinition-RunReportBundle.profile.ttl.md) 

## Resource Profile: Run Report Bundle (prescribed) 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/RunReportBundle | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:RunReportBundle |

 
Bundle profile that prescribes required slices/resources for EMS run reports. 

**Usages:**

* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ph-road-safety-ig|current/StructureDefinition/RunReportBundle)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

**Summary**

Mandatory: 8 elements(4 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [Composition - Run Report(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/CompositionRunReport)](StructureDefinition-CompositionRunReport.md)
* [Encounter - Transport / Run Report(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/EncounterTransportRunReport)](StructureDefinition-EncounterTransportRunReport.md)
* [Location - Incident / Scene(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/LocationIncident)](StructureDefinition-LocationIncident.md)
* [Observation - Triage Category (Scene)(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationTriageCategory)](StructureDefinition-ObservationTriageCategory.md)
* [Observation - Heart Rate(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationHeartRate)](StructureDefinition-ObservationHeartRate.md)
* [Observation - Blood Pressure(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationBloodPressure)](StructureDefinition-ObservationBloodPressure.md)
* [Observation - Extent of Injury(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationExtentOfInjury)](StructureDefinition-ObservationExtentOfInjury.md)
* [Observation - Vehicles Involved Count(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationVehiclesInvolved)](StructureDefinition-ObservationVehiclesInvolved.md)
* [Observation - Patients Involved Count(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationPatientsInvolved)](StructureDefinition-ObservationPatientsInvolved.md)
* [Observation - Collision Type(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationCollisionType)](StructureDefinition-ObservationCollisionType.md)
* [Observation - CCTV Available(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationCCTVAvailable)](StructureDefinition-ObservationCCTVAvailable.md)
* [Condition - Problem / Chief Complaint(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ConditionProblem)](StructureDefinition-ConditionProblem.md)
* [DocumentReference - ONEISS Run Form(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/DocumentReferenceOneissRunForm)](StructureDefinition-DocumentReferenceOneissRunForm.md)
* [Task - Delay Reporting(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/TaskDelayReporting)](StructureDefinition-TaskDelayReporting.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Bundle.entry

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Bundle](http://hl7.org/fhir/R4/bundle.html) 

**Summary**

Mandatory: 8 elements(4 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [Composition - Run Report(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/CompositionRunReport)](StructureDefinition-CompositionRunReport.md)
* [Encounter - Transport / Run Report(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/EncounterTransportRunReport)](StructureDefinition-EncounterTransportRunReport.md)
* [Location - Incident / Scene(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/LocationIncident)](StructureDefinition-LocationIncident.md)
* [Observation - Triage Category (Scene)(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationTriageCategory)](StructureDefinition-ObservationTriageCategory.md)
* [Observation - Heart Rate(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationHeartRate)](StructureDefinition-ObservationHeartRate.md)
* [Observation - Blood Pressure(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationBloodPressure)](StructureDefinition-ObservationBloodPressure.md)
* [Observation - Extent of Injury(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationExtentOfInjury)](StructureDefinition-ObservationExtentOfInjury.md)
* [Observation - Vehicles Involved Count(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationVehiclesInvolved)](StructureDefinition-ObservationVehiclesInvolved.md)
* [Observation - Patients Involved Count(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationPatientsInvolved)](StructureDefinition-ObservationPatientsInvolved.md)
* [Observation - Collision Type(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationCollisionType)](StructureDefinition-ObservationCollisionType.md)
* [Observation - CCTV Available(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ObservationCCTVAvailable)](StructureDefinition-ObservationCCTVAvailable.md)
* [Condition - Problem / Chief Complaint(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ConditionProblem)](StructureDefinition-ConditionProblem.md)
* [DocumentReference - ONEISS Run Form(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/DocumentReferenceOneissRunForm)](StructureDefinition-DocumentReferenceOneissRunForm.md)
* [Task - Delay Reporting(https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/TaskDelayReporting)](StructureDefinition-TaskDelayReporting.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Bundle.entry

 

Other representations of profile: [CSV](StructureDefinition-RunReportBundle.csv), [Excel](StructureDefinition-RunReportBundle.xlsx), [Schematron](StructureDefinition-RunReportBundle.sch) 

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package ph-road-safety-ig#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

