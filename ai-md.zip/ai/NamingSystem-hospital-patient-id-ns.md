# Hospital Patient ID No. - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Hospital Patient ID No.**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Narrative Content](#) 
*  [XML](NamingSystem-hospital-patient-id-ns.xml.md) 
*  [JSON](NamingSystem-hospital-patient-id-ns.json.md) 
*  [TTL](NamingSystem-hospital-patient-id-ns.ttl.md) 

## NamingSystem: Hospital Patient ID No. 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/NamingSystem/hospital-patient-id-ns | *Version*:0.1.0 |
| Active as of 2025-06-01 | *Computable Name*:HospitalPatientID |

 
The permanent and unique number issued by hospitals to individual patients and their dependents. 

### Summary

| | |
| :--- | :--- |
| Defining URL | https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/NamingSystem/hospital-patient-id-ns |
| Version | 0.1.0 |
| Name | HospitalPatientID |
| Status | active |
| Definition | The permanent and unique number issued by hospitals to individual patients and their dependents. |
| Publisher | UP Manila - National Institutes of Health - National Telehealth Center |

### Identifiers

* **Type**: URI
  * **Value**: http://hospital.example.org/hospital-patient-id
  * **Preferred**: true
  * **Comment**: Primary URI for Hospital Patient ID used across modern EHRs
* **Type**: OID
  * **Value**: 2.16.840.1.113883.3.72.5.9.1
  * **Preferred**: 
  * **Comment**: Legacy OID used in older EHR integrations
* **Type**: URI
  * **Value**: urn:hospital:id
  * **Preferred**: 
  * **Comment**: Alternative URN used internally for multi-EHR linkage

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

