# Location - Incident / Scene - Definitions - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location - Incident / Scene**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](StructureDefinition-LocationIncident.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-LocationIncident-mappings.md) 
*  [XML](StructureDefinition-LocationIncident.profile.xml.md) 
*  [JSON](StructureDefinition-LocationIncident.profile.json.md) 
*  [TTL](StructureDefinition-LocationIncident.profile.ttl.md) 

## Resource Profile: LocationIncident - Detailed Descriptions

| |
| :--- |
| Draft as of 2025-10-07 |

Definitions for the LocationIncident resource profile.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

