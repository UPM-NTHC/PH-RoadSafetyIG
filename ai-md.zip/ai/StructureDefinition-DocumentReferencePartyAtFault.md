# DocumentReference - Party at Fault - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DocumentReference - Party at Fault**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-DocumentReferencePartyAtFault-definitions.md) 
*  [Mappings](StructureDefinition-DocumentReferencePartyAtFault-mappings.md) 
*  [XML](StructureDefinition-DocumentReferencePartyAtFault.profile.xml.md) 
*  [JSON](StructureDefinition-DocumentReferencePartyAtFault.profile.json.md) 
*  [TTL](StructureDefinition-DocumentReferencePartyAtFault.profile.ttl.md) 

## Resource Profile: DocumentReference - Party at Fault 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/DocumentReferencePartyAtFault | *Version*:0.1.0 |
| Draft as of 2025-10-07 | *Computable Name*:DocumentReferencePartyAtFault |

 
MDS221: Party-at-fault narrative/report. 

**Usages:**

* Refer to this Profile: [Composition - Run Report](StructureDefinition-CompositionRunReport.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/example.fhir.ph.roadsafety|current/StructureDefinition/DocumentReferencePartyAtFault)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

**Summary**

Mandatory: 1 element
 Must-Support: 1 element

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

**Summary**

Mandatory: 1 element
 Must-Support: 1 element

 

Other representations of profile: [CSV](StructureDefinition-DocumentReferencePartyAtFault.csv), [Excel](StructureDefinition-DocumentReferencePartyAtFault.xlsx), [Schematron](StructureDefinition-DocumentReferencePartyAtFault.sch) 

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

