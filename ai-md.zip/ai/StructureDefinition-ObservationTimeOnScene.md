# Observation - Time On Scene - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Observation - Time On Scene**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ObservationTimeOnScene-definitions.md) 
*  [Mappings](StructureDefinition-ObservationTimeOnScene-mappings.md) 
*  [XML](StructureDefinition-ObservationTimeOnScene.profile.xml.md) 
*  [JSON](StructureDefinition-ObservationTimeOnScene.profile.json.md) 
*  [TTL](StructureDefinition-ObservationTimeOnScene.profile.ttl.md) 

## Resource Profile: Observation - Time On Scene 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/ObservationTimeOnScene | *Version*:0.1.0 |
| Draft as of 2025-10-07 | *Computable Name*:ObservationTimeOnScene |

 
MDS65: Arrival on scene timestamp. 

**Usages:**

* Refer to this Profile: [Composition - Run Report](StructureDefinition-CompositionRunReport.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/example.fhir.ph.roadsafety|current/StructureDefinition/ObservationTimeOnScene)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [ObservationScene](StructureDefinition-ObservationScene.md) 

#### Terminology Bindings

#### Constraints

This structure is derived from [ObservationScene](StructureDefinition-ObservationScene.md) 

**Summary**

Mandatory: 2 elements
 Must-Support: 1 element

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.value[x]

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [ObservationScene](StructureDefinition-ObservationScene.md) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [ObservationScene](StructureDefinition-ObservationScene.md) 

**Summary**

Mandatory: 2 elements
 Must-Support: 1 element

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.value[x]

 

Other representations of profile: [CSV](StructureDefinition-ObservationTimeOnScene.csv), [Excel](StructureDefinition-ObservationTimeOnScene.xlsx), [Schematron](StructureDefinition-ObservationTimeOnScene.sch) 

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

