# Cause of Road Crash - TTL Representation - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Cause of Road Crash**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Narrative Content](CodeSystem-cause-of-crash-cs.md) 
*  [XML](CodeSystem-cause-of-crash-cs.xml.md) 
*  [JSON](CodeSystem-cause-of-crash-cs.json.md) 
*  [TTL](#) 

## : Cause of Road Crash - TTL Representation

| |
| :--- |
| Draft as of 2025-10-08 |

[Raw ttl](CodeSystem-cause-of-crash-cs.ttl) | [Download](CodeSystem-cause-of-crash-cs.ttl)

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

