# Facility Bundle (prescribed) - XML Representation - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Facility Bundle (prescribed)**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](StructureDefinition-FacilityBundle.md) 
*  [Detailed Descriptions](StructureDefinition-FacilityBundle-definitions.md) 
*  [Mappings](StructureDefinition-FacilityBundle-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-FacilityBundle.profile.json.md) 
*  [TTL](StructureDefinition-FacilityBundle.profile.ttl.md) 

## Resource Profile: FacilityBundle - XML Profile

| |
| :--- |
| Draft as of 2025-10-07 |

XML representation of the FacilityBundle resource profile.

[Raw xml](StructureDefinition-FacilityBundle.xml) | [Download](StructureDefinition-FacilityBundle.xml)

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

