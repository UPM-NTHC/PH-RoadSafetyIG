#  - DRAFT PH Road Safety Implementation Guide v0.1.0

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/history.html)

*  [Content](StructureDefinition-ObservationConditionOfPatient.md) 
*  [Detailed Descriptions](StructureDefinition-ObservationConditionOfPatient-definitions.md) 
*  [Mappings](StructureDefinition-ObservationConditionOfPatient-mappings.md) 
*  [XML](StructureDefinition-ObservationConditionOfPatient.profile.xml.md) 
*  [JSON](StructureDefinition-ObservationConditionOfPatient.profile.json.md) 
*  [TTL](StructureDefinition-ObservationConditionOfPatient.profile.ttl.md) 

## Resource Profile: ObservationConditionOfPatient - Change History

| |
| :--- |
| Draft as of 2025-10-06 |

Changes in the ObservationConditionOfPatient resource profile.

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package ph-road-safety-ig#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

