# Condition - Initial Impression - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Condition - Initial Impression**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ConditionInitialImpression-definitions.md) 
*  [Mappings](StructureDefinition-ConditionInitialImpression-mappings.md) 
*  [XML](StructureDefinition-ConditionInitialImpression.profile.xml.md) 
*  [JSON](StructureDefinition-ConditionInitialImpression.profile.json.md) 
*  [TTL](StructureDefinition-ConditionInitialImpression.profile.ttl.md) 

## Resource Profile: Condition - Initial Impression 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ConditionInitialImpression | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:ConditionInitialImpression |

 
ONEISS: Initial impression on patient condition. 

**Usages:**

* Use this Profile: [Facility Bundle (prescribed)](StructureDefinition-FacilityBundle.md)
* Refer to this Profile: [Composition - Facility Report](StructureDefinition-CompositionFacility.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ph-road-safety-ig|current/StructureDefinition/ConditionInitialImpression)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [ConditionRoadSafety](StructureDefinition-ConditionRoadSafety.md) 

#### Terminology Bindings

#### Constraints

This structure is derived from [ConditionRoadSafety](StructureDefinition-ConditionRoadSafety.md) 

**Summary**

Mandatory: 1 element
 Must-Support: 1 element

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [ConditionRoadSafety](StructureDefinition-ConditionRoadSafety.md) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [ConditionRoadSafety](StructureDefinition-ConditionRoadSafety.md) 

**Summary**

Mandatory: 1 element
 Must-Support: 1 element

 

Other representations of profile: [CSV](StructureDefinition-ConditionInitialImpression.csv), [Excel](StructureDefinition-ConditionInitialImpression.xlsx), [Schematron](StructureDefinition-ConditionInitialImpression.sch) 

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package ph-road-safety-ig#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

