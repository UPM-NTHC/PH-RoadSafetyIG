# Run Report Composition Sections - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Run Report Composition Sections**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-RSRunSectionCS.xml.md) 
*  [JSON](CodeSystem-RSRunSectionCS.json.md) 
*  [TTL](CodeSystem-RSRunSectionCS.ttl.md) 

## CodeSystem: Run Report Composition Sections 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/CodeSystem/RSRunSectionCS | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:RSRunSectionCS |

 This Code system is referenced in the content logical definition of the following value sets: 

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

This code system `https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/CodeSystem/RSRunSectionCS` defines the following codes:

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package ph-road-safety-ig#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

