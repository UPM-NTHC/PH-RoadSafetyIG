# Condition - Initial Impression - Mappings - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Condition - Initial Impression**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](StructureDefinition-ConditionInitialImpression.md) 
*  [Detailed Descriptions](StructureDefinition-ConditionInitialImpression-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-ConditionInitialImpression.profile.xml.md) 
*  [JSON](StructureDefinition-ConditionInitialImpression.profile.json.md) 
*  [TTL](StructureDefinition-ConditionInitialImpression.profile.ttl.md) 

## Resource Profile: ConditionInitialImpression - Mappings

| |
| :--- |
| Draft as of 2025-10-07 |

Mappings for the ConditionInitialImpression resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-07 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

