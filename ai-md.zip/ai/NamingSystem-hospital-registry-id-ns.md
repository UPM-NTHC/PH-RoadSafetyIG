# National Health Facility Registry ID - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **National Health Facility Registry ID**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Narrative Content](#) 
*  [XML](NamingSystem-hospital-registry-id-ns.xml.md) 
*  [JSON](NamingSystem-hospital-registry-id-ns.json.md) 
*  [TTL](NamingSystem-hospital-registry-id-ns.ttl.md) 

## NamingSystem: National Health Facility Registry ID 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/NamingSystem/hospital-registry-id-ns | *Version*:0.1.0 |
| Draft as of 2025-06-01 | *Computable Name*:NHFR |

 
The permanent and unique number issued by PhilHealth to individual members and to each and every dependent. 

### Summary

| | |
| :--- | :--- |
| Defining URL | https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/NamingSystem/hospital-registry-id-ns |
| Version | 0.1.0 |
| Name | NHFR |
| Status | draft |
| Definition | The permanent and unique number issued by PhilHealth to individual members and to each and every dependent. |
| Publisher | UP Manila - National Institutes of Health - National Telehealth Center |

### Identifiers

* **Type**: URI
  * **Value**: https://nhfr.doh.gov.ph/

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

