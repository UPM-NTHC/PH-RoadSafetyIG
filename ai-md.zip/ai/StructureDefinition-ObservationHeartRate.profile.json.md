# Observation - Heart Rate - JSON Representation - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Observation - Heart Rate**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/history.html)

*  [Content](StructureDefinition-ObservationHeartRate.md) 
*  [Detailed Descriptions](StructureDefinition-ObservationHeartRate-definitions.md) 
*  [Mappings](StructureDefinition-ObservationHeartRate-mappings.md) 
*  [XML](StructureDefinition-ObservationHeartRate.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-ObservationHeartRate.profile.ttl.md) 

## Resource Profile: ObservationHeartRate - JSON Profile

| |
| :--- |
| Draft as of 2025-10-06 |

JSON representation of the ObservationHeartRate resource profile.

[Raw json](StructureDefinition-ObservationHeartRate.json) | [Download](StructureDefinition-ObservationHeartRate.json)

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package ph-road-safety-ig#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

