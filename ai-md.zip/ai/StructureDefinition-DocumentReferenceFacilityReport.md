# DocumentReference - ONEISS Facility Report - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DocumentReference - ONEISS Facility Report**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-DocumentReferenceFacilityReport-definitions.md) 
*  [Mappings](StructureDefinition-DocumentReferenceFacilityReport-mappings.md) 
*  [XML](StructureDefinition-DocumentReferenceFacilityReport.profile.xml.md) 
*  [JSON](StructureDefinition-DocumentReferenceFacilityReport.profile.json.md) 
*  [TTL](StructureDefinition-DocumentReferenceFacilityReport.profile.ttl.md) 

## Resource Profile: DocumentReference - ONEISS Facility Report 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/DocumentReferenceFacilityReport | *Version*:0.1.0 |
| Draft as of 2025-10-08 | *Computable Name*:DocumentReferenceFacilityReport |

 
DocumentReference profile for the ONEISS facility report (scan or link). 

**Usages:**

* Use this Profile: [Facility Bundle (prescribed)](StructureDefinition-FacilityBundle.md)
* Refer to this Profile: [Composition - Facility Report](StructureDefinition-CompositionFacility.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/example.fhir.ph.roadsafety|current/StructureDefinition/DocumentReferenceFacilityReport)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

**Summary**

Mandatory: 1 element
 Must-Support: 4 elements

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

**Summary**

Mandatory: 1 element
 Must-Support: 4 elements

 

Other representations of profile: [CSV](StructureDefinition-DocumentReferenceFacilityReport.csv), [Excel](StructureDefinition-DocumentReferenceFacilityReport.xlsx), [Schematron](StructureDefinition-DocumentReferenceFacilityReport.sch) 

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

