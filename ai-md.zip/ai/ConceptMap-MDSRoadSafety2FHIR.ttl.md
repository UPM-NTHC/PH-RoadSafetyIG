# MDS Logical Model to FHIR Mapping - TTL Representation - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MDS Logical Model to FHIR Mapping**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Narrative Content](ConceptMap-MDSRoadSafety2FHIR.md) 
*  [XML](ConceptMap-MDSRoadSafety2FHIR.xml.md) 
*  [JSON](ConceptMap-MDSRoadSafety2FHIR.json.md) 
*  [TTL](#) 

## : MDS Logical Model to FHIR Mapping - TTL Representation

| |
| :--- |
| Active as of 2025-10-08 |

[Raw ttl](ConceptMap-MDSRoadSafety2FHIR.ttl) | [Download](ConceptMap-MDSRoadSafety2FHIR.ttl)

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

