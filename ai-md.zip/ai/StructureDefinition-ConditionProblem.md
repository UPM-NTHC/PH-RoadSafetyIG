# Condition - Problem / Chief Complaint - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Condition - Problem / Chief Complaint**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ConditionProblem-definitions.md) 
*  [Mappings](StructureDefinition-ConditionProblem-mappings.md) 
*  [XML](StructureDefinition-ConditionProblem.profile.xml.md) 
*  [JSON](StructureDefinition-ConditionProblem.profile.json.md) 
*  [TTL](StructureDefinition-ConditionProblem.profile.ttl.md) 

## Resource Profile: Condition - Problem / Chief Complaint 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/ConditionProblem | *Version*:0.1.0 |
| Draft as of 2025-10-06 | *Computable Name*:ConditionProblem |

 
MDS89: Problem (chief complaint as code/text). 

**Usages:**

* Use this Profile: [Run Report Bundle (prescribed)](StructureDefinition-RunReportBundle.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ph-road-safety-ig|current/StructureDefinition/ConditionProblem)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Condition](http://hl7.org/fhir/R4/condition.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Condition](http://hl7.org/fhir/R4/condition.html) 

**Summary**

Mandatory: 1 element
 Must-Support: 2 elements

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Condition](http://hl7.org/fhir/R4/condition.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Condition](http://hl7.org/fhir/R4/condition.html) 

**Summary**

Mandatory: 1 element
 Must-Support: 2 elements

 

Other representations of profile: [CSV](StructureDefinition-ConditionProblem.csv), [Excel](StructureDefinition-ConditionProblem.xlsx), [Schematron](StructureDefinition-ConditionProblem.sch) 

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package ph-road-safety-ig#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-06 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

