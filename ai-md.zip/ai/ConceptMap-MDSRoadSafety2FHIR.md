# MDS Logical Model to FHIR Mapping - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MDS Logical Model to FHIR Mapping**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-MDSRoadSafety2FHIR.xml.md) 
*  [JSON](ConceptMap-MDSRoadSafety2FHIR.json.md) 
*  [TTL](ConceptMap-MDSRoadSafety2FHIR.ttl.md) 

## ConceptMap: MDS Logical Model to FHIR Mapping 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/ConceptMap/MDSRoadSafety2FHIR | *Version*:0.1.0 |
| Active as of 2025-10-08 | *Computable Name*:MDSRoadSafety2FHIR |

 
Maps elements from the MDSRoadSafety logical model to target FHIR R4 resources. 

Mapping from https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/MDSRoadSafety to http://hl7.org/fhir/R4

**Group 1**Mapping from `https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/MDSRoadSafety` to [Encounter](http://hl7.org/fhir/R4/encounter.html)

* **Source Code**: MDSRoadSafety.encounter.incidentNumber
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.identifier
* **Source Code**: MDSRoadSafety.encounter.hospitalCaseNo
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.identifier
* **Source Code**: MDSRoadSafety.encounter.typeOfPatient
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.class
* **Source Code**: MDSRoadSafety.encounter.dateTimeOfConsult
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.period.start
* **Source Code**: MDSRoadSafety.encounter.serviceProvider
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.serviceProvider
* **Source Code**: MDSRoadSafety.workflow.receivedBy
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.participant.individual
* **Source Code**: MDSRoadSafety.workflow.crew.teamLeader
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.participant.individual
* **Source Code**: MDSRoadSafety.workflow.crew.treatmentOfficer
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.participant.individual
* **Source Code**: MDSRoadSafety.workflow.crew.transportOfficer
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.participant.individual
* **Source Code**: MDSRoadSafety.workflow.crew.assistant
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.participant.individual
* **Source Code**: MDSRoadSafety.encounter.originating.organization
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.hospitalization.origin
* **Source Code**: MDSRoadSafety.encounter.originating.practitioner
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.participant.individual
* **Source Code**: MDSRoadSafety.encounter.disposition
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.hospitalization.dischargeDisposition
* **Source Code**: MDSRoadSafety.encounter.disposition.text
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.hospitalization.dischargeDisposition.text
* **Source Code**: MDSRoadSafety.encounter.transferDestination
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Encounter.hospitalization.destination

-------

**Group 2**Mapping from `https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/MDSRoadSafety` to [Patient](http://hl7.org/fhir/R4/patient.html)

* **Source Code**: MDSRoadSafety.patient.name.family
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.name.family
* **Source Code**: MDSRoadSafety.patient.name.given
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.name.given
* **Source Code**: MDSRoadSafety.patient.birthDate
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.birthDate
* **Source Code**: MDSRoadSafety.patient.gender
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.gender
* **Source Code**: MDSRoadSafety.patient.telecom
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.telecom
* **Source Code**: MDSRoadSafety.patient.identifier
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.identifier
* **Source Code**: MDSRoadSafety.patient.occupation
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.extension:occupation
* **Source Code**: MDSRoadSafety.patient.address.line
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.address.line
* **Source Code**: MDSRoadSafety.patient.address.extension[barangay]
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.address.extension:barangay
* **Source Code**: MDSRoadSafety.patient.address.extension[cityMunicipality]
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.address.extension:cityMunicipality
* **Source Code**: MDSRoadSafety.patient.address.extension[province]
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.address.extension:province
* **Source Code**: MDSRoadSafety.patient.address.extension[region]
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Patient.address.extension:region

-------

**Group 3**Mapping from `https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/MDSRoadSafety` to [Location](http://hl7.org/fhir/R4/location.html)

* **Source Code**: MDSRoadSafety.incident.location.street
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Location.address.line
* **Source Code**: MDSRoadSafety.incident.location.barangay
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Location.address.extension:barangay
* **Source Code**: MDSRoadSafety.incident.location.city
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Location.address.extension:cityMunicipality
* **Source Code**: MDSRoadSafety.incident.location.province
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Location.address.extension:province
* **Source Code**: MDSRoadSafety.incident.location.region
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Location.address.extension:region
* **Source Code**: MDSRoadSafety.incident.location.position.longitude
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Location.position.longitude
* **Source Code**: MDSRoadSafety.incident.location.position.latitude
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Location.position.latitude

-------

**Group 4**Mapping from `https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/MDSRoadSafety` to [ServiceRequest](http://hl7.org/fhir/R4/servicerequest.html)

* **Source Code**: MDSRoadSafety.workflow.refusalToAdmit.flag
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ServiceRequest.status
* **Source Code**: MDSRoadSafety.workflow.refusalToAdmit.hospital
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ServiceRequest.supportingInfo
* **Source Code**: MDSRoadSafety.workflow.refusalToAdmit.physician
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ServiceRequest.supportingInfo
* **Source Code**: MDSRoadSafety.workflow.refusalToAdmit.dateTime
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: ServiceRequest.occurrenceDateTime

-------

**Group 5**Mapping from `https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/MDSRoadSafety` to [Procedure](http://hl7.org/fhir/R4/procedure.html)

* **Source Code**: MDSRoadSafety.workflow.transportCoordinated
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Procedure.code
* **Source Code**: MDSRoadSafety.clinical.psychosocialSupport
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Procedure.code
* **Source Code**: MDSRoadSafety.clinical.intervention
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Procedure.code

-------

**Group 6**Mapping from `https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/MDSRoadSafety` to [Observation](http://hl7.org/fhir/R4/observation.html)

* **Source Code**: MDSRoadSafety.workflow.dateReceived
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueDateTime
* **Source Code**: MDSRoadSafety.workflow.timeEnroute
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueDateTime
* **Source Code**: MDSRoadSafety.workflow.timeOnScene
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueDateTime
* **Source Code**: MDSRoadSafety.workflow.timeDepartedScene
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueDateTime
* **Source Code**: MDSRoadSafety.workflow.timeHospitalArrival
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueDateTime
* **Source Code**: MDSRoadSafety.workflow.timeStationArrival
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueDateTime
* **Source Code**: MDSRoadSafety.incident.injuryDateTime
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueDateTime
* **Source Code**: MDSRoadSafety.incident.injuryIntent
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.transportOrVehicular
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.incident.transportModeToFacility
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.transportModeOther
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.triagePriority
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.urgency
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.placeOfOccurrence
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.placeOfOccurrenceOther
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.activityAtTime
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.activityOther
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.collisionVsNonCollision
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.patientsVehicle
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.patientsVehicleOther
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.otherVehicleOrObject
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.otherVehicleOther
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.positionOfPatient
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.positionOfPatientOther
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.howManyVehicles
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueInteger
* **Source Code**: MDSRoadSafety.incident.howManyPatients
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueInteger
* **Source Code**: MDSRoadSafety.incident.collisionType
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.trafficInvestigatorPresent
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.incident.otherRiskFactors
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.otherRiskFactorsOther
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.safetyAccessories
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.safetyAccessoriesOther
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.reportedComplaint
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueString
* **Source Code**: MDSRoadSafety.incident.callSource
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueString
* **Source Code**: MDSRoadSafety.vitals.time
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.effectiveDateTime
* **Source Code**: MDSRoadSafety.vitals.respiratoryRate
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueQuantity
* **Source Code**: MDSRoadSafety.vitals.respiratoryRhythm
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.vitals.breathSounds
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.vitals.pulseRate
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueQuantity
* **Source Code**: MDSRoadSafety.vitals.pulseRhythm
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.vitals.pulseQuality
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.vitals.bloodPressure.systolic
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.component:bpSystolic.valueQuantity
* **Source Code**: MDSRoadSafety.vitals.bloodPressure.diastolic
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.component:bpDiastolic.valueQuantity
* **Source Code**: MDSRoadSafety.vitals.temperature
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueQuantity
* **Source Code**: MDSRoadSafety.vitals.levelOfConsciousness
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.vitals.pupils
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.vitals.gcs.eyes
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.component:gcsEyes.valueCodeableConcept
* **Source Code**: MDSRoadSafety.vitals.gcs.verbal
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.component:gcsVerbal.valueCodeableConcept
* **Source Code**: MDSRoadSafety.vitals.gcs.motor
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.component:gcsMotor.valueCodeableConcept
* **Source Code**: MDSRoadSafety.vitals.gcs.total
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueInteger

-------

**Group 7**Mapping from `https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/MDSRoadSafety` to [Observation](http://hl7.org/fhir/R4/observation.html)

* **Source Code**: MDSRoadSafety.injuries.multipleInjuries
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.injuries.abrasion.present
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.injuries.abrasion.site
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.bodySite
* **Source Code**: MDSRoadSafety.injuries.abrasion.details
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.note
* **Source Code**: MDSRoadSafety.injuries.avulsion.present
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.injuries.avulsion.site
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.bodySite
* **Source Code**: MDSRoadSafety.injuries.avulsion.details
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.note
* **Source Code**: MDSRoadSafety.injuries.burn.present
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.injuries.burn.firstDegree.site
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.bodySite
* **Source Code**: MDSRoadSafety.injuries.burn.firstDegree.details
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.note
* **Source Code**: MDSRoadSafety.injuries.burn.secondDegree.site
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.bodySite
* **Source Code**: MDSRoadSafety.injuries.burn.secondDegree.details
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.note
* **Source Code**: MDSRoadSafety.injuries.burn.thirdDegree.site
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.bodySite
* **Source Code**: MDSRoadSafety.injuries.burn.thirdDegree.details
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.note
* **Source Code**: MDSRoadSafety.injuries.burn.fourthDegree.site
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.bodySite
* **Source Code**: MDSRoadSafety.injuries.burn.fourthDegree.details
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.note
* **Source Code**: MDSRoadSafety.injuries.concussion.present
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.injuries.concussion.site
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.bodySite
* **Source Code**: MDSRoadSafety.injuries.concussion.details
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.note
* **Source Code**: MDSRoadSafety.injuries.contusion.present
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.injuries.contusion.site
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.bodySite
* **Source Code**: MDSRoadSafety.injuries.contusion.details
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.note
* **Source Code**: MDSRoadSafety.injuries.fracture.present
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.injuries.fracture.closed.site
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.bodySite
* **Source Code**: MDSRoadSafety.injuries.fracture.closed.details
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.note
* **Source Code**: MDSRoadSafety.injuries.fracture.open.site
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.bodySite
* **Source Code**: MDSRoadSafety.injuries.fracture.open.details
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.note
* **Source Code**: MDSRoadSafety.injuries.openWound.present
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.injuries.openWound.site
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.bodySite
* **Source Code**: MDSRoadSafety.injuries.openWound.details
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.note
* **Source Code**: MDSRoadSafety.injuries.traumaticAmputation.present
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.injuries.traumaticAmputation.site
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.bodySite
* **Source Code**: MDSRoadSafety.injuries.traumaticAmputation.details
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.note
* **Source Code**: MDSRoadSafety.injuries.otherInjury.present
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.injuries.otherInjury.site
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.bodySite
* **Source Code**: MDSRoadSafety.injuries.otherInjury.details
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.note
* **Source Code**: MDSRoadSafety.incident.externalCauses.bitesStings
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.incident.externalCauses.bitesStingsAgent
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.externalCauses.burns
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.incident.externalCauses.burnsAgent
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.externalCauses.burnsOther
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueString
* **Source Code**: MDSRoadSafety.incident.externalCauses.chemicalSubstance
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.incident.externalCauses.chemicalAgent
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.externalCauses.sharpObject
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.incident.externalCauses.sharpObjectSpecify
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueString
* **Source Code**: MDSRoadSafety.incident.externalCauses.drowning
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.incident.externalCauses.drowningType
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueCodeableConcept
* **Source Code**: MDSRoadSafety.incident.externalCauses.drowningOther
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueString
* **Source Code**: MDSRoadSafety.incident.externalCauses.forcesOfNature
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.incident.externalCauses.fall
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.incident.externalCauses.fallSpecifics
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueString
* **Source Code**: MDSRoadSafety.incident.externalCauses.firecracker
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.incident.externalCauses.firecrackerType
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueString
* **Source Code**: MDSRoadSafety.incident.externalCauses.gunshot
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.incident.externalCauses.gunshotWeapon
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueString
* **Source Code**: MDSRoadSafety.incident.externalCauses.hangingStrangulation
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.incident.externalCauses.maulingAssault
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.incident.externalCauses.sexualAssault
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.incident.externalCauses.other
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueBoolean
* **Source Code**: MDSRoadSafety.incident.externalCauses.otherSpecify
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Observation.valueString

-------

**Group 8**Mapping from `https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/MDSRoadSafety` to [Condition](http://hl7.org/fhir/R4/condition.html)

* **Source Code**: MDSRoadSafety.clinical.medicalHistory
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Condition.code
* **Source Code**: MDSRoadSafety.clinical.initialImpression
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Condition.code
* **Source Code**: MDSRoadSafety.clinical.icd10NatureOfInjury
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Condition.code
* **Source Code**: MDSRoadSafety.clinical.icd10ExternalCause
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Condition.code

-------

**Group 9**Mapping from `https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/MDSRoadSafety` to [MedicationStatement](http://hl7.org/fhir/R4/medicationstatement.html)

* **Source Code**: MDSRoadSafety.clinical.currentMedication
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: MedicationStatement.medicationCodeableConcept

-------

**Group 10**Mapping from `https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/MDSRoadSafety` to [AllergyIntolerance](http://hl7.org/fhir/R4/allergyintolerance.html)

* **Source Code**: MDSRoadSafety.clinical.knownAllergies
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: AllergyIntolerance.code

-------

**Group 11**Mapping from `https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/MDSRoadSafety` to [DocumentReference](http://hl7.org/fhir/R4/documentreference.html)

* **Source Code**: MDSRoadSafety.evidence.causeOfCrash
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: DocumentReference.content.attachment.url
* **Source Code**: MDSRoadSafety.evidence.partyAtFault
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: DocumentReference.content.attachment.url
* **Source Code**: MDSRoadSafety.evidence.trafficIncidentManagement
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: DocumentReference.content.attachment.url
* **Source Code**: MDSRoadSafety.evidence.roadNetworkShapeFiles
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: DocumentReference.content.attachment.url
* **Source Code**: MDSRoadSafety.evidence.cctvReconstruction.link
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: DocumentReference.content.attachment.url

-------

**Group 12**Mapping from `https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG/StructureDefinition/MDSRoadSafety` to [Claim](http://hl7.org/fhir/R4/claim.html)

* **Source Code**: MDSRoadSafety.finance.costOfCare
  * **Relationship**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Target Code**: Claim.total

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

