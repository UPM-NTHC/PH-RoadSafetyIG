# Observation - Facility / ONEISS - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Observation - Facility / ONEISS**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ObservationFacility-definitions.md) 
*  [Mappings](StructureDefinition-ObservationFacility-mappings.md) 
*  [XML](StructureDefinition-ObservationFacility.profile.xml.md) 
*  [JSON](StructureDefinition-ObservationFacility.profile.json.md) 
*  [TTL](StructureDefinition-ObservationFacility.profile.ttl.md) 

## Resource Profile: Observation - Facility / ONEISS 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/ObservationFacility | *Version*:0.1.0 |
| Draft as of 2025-10-08 | *Computable Name*:ObservationFacility |

 
Observation profile for facility-collected vitals and clinical observations for ONEISS reporting. Intended to be derived from PH‑CORE Observation profile when available. 

**Usages:**

* Derived from this Profile: [Observation - Condition of Patient](StructureDefinition-ObservationConditionOfPatient.md), [Observation - ED Blood Pressure](StructureDefinition-ObservationEDBloodPressure.md), [Observation - ED Heart Rate](StructureDefinition-ObservationEDHeartRate.md), [Observation - Mode of Transport to Facility](StructureDefinition-ObservationModeOfTransport.md)...Show 2 more,[Observation - Outcome at Discharge](StructureDefinition-ObservationOutcomeAtDischarge.md)and[Observation - Status on Arrival](StructureDefinition-ObservationStatusOnArrival.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/example.fhir.ph.roadsafety|current/StructureDefinition/ObservationFacility)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [PHCoreObservation](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-observation.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [PHCoreObservation](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-observation.html) 

**Summary**

Mandatory: 1 element

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.value[x]

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [PHCoreObservation](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-observation.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [PHCoreObservation](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-observation.html) 

**Summary**

Mandatory: 1 element

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.value[x]

 

Other representations of profile: [CSV](StructureDefinition-ObservationFacility.csv), [Excel](StructureDefinition-ObservationFacility.xlsx), [Schematron](StructureDefinition-ObservationFacility.sch) 

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

