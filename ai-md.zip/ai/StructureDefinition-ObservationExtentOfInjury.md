# Observation - Extent of Injury - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Observation - Extent of Injury**

DRAFT PH Road Safety Implementation Guide - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-ObservationExtentOfInjury-definitions.md) 
*  [Mappings](StructureDefinition-ObservationExtentOfInjury-mappings.md) 
*  [XML](StructureDefinition-ObservationExtentOfInjury.profile.xml.md) 
*  [JSON](StructureDefinition-ObservationExtentOfInjury.profile.json.md) 
*  [TTL](StructureDefinition-ObservationExtentOfInjury.profile.ttl.md) 

## Resource Profile: Observation - Extent of Injury 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/ObservationExtentOfInjury | *Version*:0.1.0 |
| Draft as of 2025-10-08 | *Computable Name*:ObservationExtentOfInjury |

 
MDS109: Extent/severity estimate/category (free text/category). 

**Usages:**

* Use this Profile: [Run Report Bundle (prescribed)](StructureDefinition-RunReportBundle.md)
* Refer to this Profile: [Composition - Run Report](StructureDefinition-CompositionRunReport.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/example.fhir.ph.roadsafety|current/StructureDefinition/ObservationExtentOfInjury)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [ObservationScene](StructureDefinition-ObservationScene.md) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

This structure is derived from [ObservationScene](StructureDefinition-ObservationScene.md) 

**Summary**

Mandatory: 2 elements
 Must-Support: 1 element

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.value[x]

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [ObservationScene](StructureDefinition-ObservationScene.md) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [ObservationScene](StructureDefinition-ObservationScene.md) 

**Summary**

Mandatory: 2 elements
 Must-Support: 1 element

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.value[x]

 

Other representations of profile: [CSV](StructureDefinition-ObservationExtentOfInjury.csv), [Excel](StructureDefinition-ObservationExtentOfInjury.xlsx), [Schematron](StructureDefinition-ObservationExtentOfInjury.sch) 

 IG © 2025+ [UP Manila - National Institutes of Health - National Telehealth Center](https://github.com/UPM-NTHC/PH-RoadSafetyIG). Package example.fhir.ph.roadsafety#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

