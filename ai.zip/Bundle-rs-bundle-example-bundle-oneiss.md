# ONEISS Bundle – Reyes - DRAFT PH Road Safety Implementation Guide v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ONEISS Bundle – Reyes**

## Example Bundle: ONEISS Bundle – Reyes

Profile: [RS Bundle — ONEISS Submission](StructureDefinition-rs-bundle-oneiss.md)

Bundle rs-bundle-example-bundle-oneiss of type transaction

-------

Entry 1 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111102

Resource Patient:

> RS-Example Patient: Thomas Niccolo Filamor Reyes, male, born 1990-01-01. Address: 123 Sampaloc Street, Manila 1008, PH. Phone: +63-912-345-6789; Email: thomas.reyes@example.com

-------

Entry 2 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111103

Resource Encounter:

> Example RS Encounter for rs-example-patient covering an ER visit on 2025-10-31 following a vehicular incident.

-------

Entry 3 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111104

Resource Condition:

> 

Profile: [RS Condition — Initial Impression](StructureDefinition-rs-condition-initial-impression.md)

**clinicalStatus**:Active**verificationStatus**:Provisional**category**:Preliminary diagnosis**code**:Injury of multiple body regions (disorder)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**onset**: 2025-10-31 15:55:00+0800**note**:
> 

Polytrauma following multi-vehicle collision; hemodynamics stabilised upon arrival.



-------

Entry 4 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111105

Resource Condition:

> 

Profile: [RS Condition — Final Diagnosis](StructureDefinition-rs-condition-final-diagnosis.md)

**clinicalStatus**:Active**verificationStatus**:Confirmed**code**:Closed fracture of shaft of femur (disorder)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**recordedDate**: 2025-11-01 09:00:00+0800**note**:
> 

Closed mid-shaft femur fracture confirmed via radiograph; scheduled for operative fixation.



-------

Entry 5 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111106

Resource Observation:

> 

Profile: [RS Observation - Other Risk Factors](StructureDefinition-rs-observation-other-risk-factors.md)

**status**: Final**code**:Risk factor (observable entity)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:56:00+0800**value**:Alcohol/liquor

-------

Entry 6 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111107

Resource Observation:

> 

Profile: [RS Observation - Blood Alcohol Concentration](StructureDefinition-rs-observation-blood-alcohol.md)

**status**: Final**code**:Blood ethanol measurement (procedure)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:28:00+0800**value**: 0.06 g/dL(Details: UCUM codeg/dL = 'g/dL')

-------

Entry 7 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111108

Resource Observation:

> 

Profile: [RS Observation - Condition of Patient](StructureDefinition-rs-observation-condition-of-patient.md)

**status**: Final**code**:Patient status determination (procedure)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 16:58:00+0800**value**:Stable

-------

Entry 8 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111109

Resource Observation:

> 

Profile: [RS Observation - Status on Arrival](StructureDefinition-rs-observation-status-on-arrival.md)

**status**: Final**code**:Patient status finding (finding)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:04:00+0800**value**:Alive

-------

Entry 9 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111110

Resource Observation:

> 

Profile: [RS Observation - Outcome at Release](StructureDefinition-rs-observation-outcome-release.md)

**status**: Final**code**:Patient condition finding (finding)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 16:34:00+0800**value**:Improved

-------

Entry 10 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111111

Resource Observation:

> 

Profile: [RS Observation - Transferred From Facility](StructureDefinition-rs-observation-transferred-from-facility.md)

**status**: Final**code**:Transferred from another acute care facility [NTDS]**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 16:30:00+0800**value**: true

-------

Entry 11 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111112

Resource Observation:

> 

Profile: [RS Observation - Referred By Facility](StructureDefinition-rs-observation-referred-by-facility.md)

**status**: Final**code**:Referral by establishment (procedure)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 16:32:00+0800**value**: true

-------

Entry 12 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111113

Resource Observation:

> 

Profile: [RS Observation - Multiple Injuries?](StructureDefinition-rs-observation-multiple-injuries.md)

**status**: Final**code**:Multiple injuries (disorder)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:30:00+0800**value**: true

-------

Entry 13 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111114

Resource Observation:

> 

Profile: [RS Observation - Abrasion](StructureDefinition-rs-observation-abrasion.md)

**status**: Final**code**:Abrasion (disorder)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:32:00+0800**value**: true**note**:
> 

Superficial abrasion on left forearm


**bodySite**:Arm

-------

Entry 14 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111115

Resource Observation:

> 

Profile: [RS Observation - Avulsion](StructureDefinition-rs-observation-avulsion.md)

**status**: Final**code**:Avulsion - injury (disorder)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:34:00+0800**value**: true**note**:
> 

Partial nail avulsion on right index finger


**bodySite**:Hand structure

-------

Entry 15 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111116

Resource Observation:

> 

Profile: [RS Observation - External Cause: Burns](StructureDefinition-rs-observation-nature-burns.md)

**status**: Final**code**:Burn (disorder)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:36:00+0800**value**:1st Degree Burn**note**:
> 

Mild burn on right forearm



-------

Entry 16 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111117

Resource Observation:

> 

Profile: [RS Observation - Concussion](StructureDefinition-rs-observation-concussion.md)

**status**: Final**code**:Concussion injury of brain (disorder)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:38:00+0800**value**: true**note**:
> 

Brief loss of consciousness reported


**bodySite**:Head structure

-------

Entry 17 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111118

Resource Observation:

> 

Profile: [RS Observation - Contusion](StructureDefinition-rs-observation-contusion.md)

**status**: Final**code**:Contusion (disorder)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:40:00+0800**value**: true**note**:
> 

Bruising on left thigh


**bodySite**:Thigh structure

-------

Entry 18 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111119

Resource Observation:

> 

Profile: [RS Observation - Fracture](StructureDefinition-rs-observation-fracture.md)

**status**: Final**code**:Fracture of bone (disorder)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:42:00+0800**value**:Closed fracture**note**:
> 

Closed fracture of left radius


**bodySite**:Radius bone structure

-------

Entry 19 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111120

Resource Observation:

> 

Profile: [RS Observation - Open Wound](StructureDefinition-rs-observation-open-wound.md)

**status**: Final**code**:Open wound (disorder)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:44:00+0800**value**:Laceration from glass**bodySite**:Forearm structure

-------

Entry 20 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111121

Resource Observation:

> 

Profile: [RS Observation - Traumatic Amputation](StructureDefinition-rs-observation-traumatic-amputation.md)

**status**: Final**code**:Traumatic amputation (disorder)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:46:00+0800**value**: false**note**:
> 

No amputation observed



-------

Entry 21 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111122

Resource Observation:

> 

Profile: [RS Observation - Other Specified Injury](StructureDefinition-rs-observation-other-injury.md)

**status**: Final**code**:Traumatic or non-traumatic injury (disorder)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:48:00+0800**value**:Soft tissue swelling on ankle**bodySite**:Ankle structure

-------

Entry 22 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111123

Resource Observation:

> 

Profile: [RS Observation - Date/Time of Injury](StructureDefinition-rs-observation-injury-datetime.md)

**status**: Final**code**:Date of event (observable entity)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:14:00+0800**value**: 2025-10-31 15:20:00+0800

-------

Entry 23 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111124

Resource Observation:

> 

Profile: [RS Observation - Injury Intent](StructureDefinition-rs-observation-injury-intent.md)

**status**: Final**code**:Injury intent**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 15:45:00+0800**value**:Unintentional/Accidental

-------

Entry 24 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111125

Resource Observation:

> 

Profile: [RS Observation - Transport/Vehicular Accident](StructureDefinition-rs-observation-transport-vehicular-accident.md)

**status**: Final**code**:Transport accident (event)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 16:26:00+0800**value**: true

-------

Entry 25 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111126

Resource Observation:

> 

Profile: [RS Observation - Mode of Transport to Facility](StructureDefinition-rs-observation-mode-of-transport.md)

**status**: Final**code**:Transport mode to hospital [NTDS]**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:06:00+0800**value**:Ambulance

-------

Entry 26 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111127

Resource Observation:

> 

Profile: [RS Observation - Collision vs Non-Collision](StructureDefinition-rs-observation-collision-vs-noncollision.md)

**status**: Final**code**:FOR TRANSPORT/VEHICULAR ACCIDENT ONLY (Collision; Non-Collision)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:16:00+0800**value**:Collision

-------

Entry 27 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111128

Resource Observation:

> 

Profile: [RS Observation - Patient's Vehicle](StructureDefinition-rs-observation-patients-vehicle.md)

**status**: Final**code**:Vehicles Involved: Patient's Vehicle**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:18:00+0800**value**:Car

-------

Entry 28 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111129

Resource Observation:

> 

Profile: [RS Observation - Other Vehicle/Object Involved](StructureDefinition-rs-observation-other-vehicle.md)

**status**: Final**code**:Other Vehicle/Object Involved (for COLLISION accident ONLY)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:20:00+0800**value**:Motorcycle

-------

Entry 29 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111130

Resource Observation:

> 

Profile: [RS Observation - Position of Patient](StructureDefinition-rs-observation-position-of-patient.md)

**status**: Final**code**:Position of Patient**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:22:00+0800**value**:Pedestrian

-------

Entry 30 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111131

Resource Observation:

> 

Profile: [RS Observation - How Many Vehicles Involved](StructureDefinition-rs-observation-how-many-vehicles.md)

**status**: Final**code**:Vehicles Involved: Patient's Vehicle**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:12:00+0800**value**: 3

-------

Entry 31 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111132

Resource Observation:

> 

Profile: [RS Observation - Place of Occurrence](StructureDefinition-rs-observation-place-of-occurrence.md)

**status**: Final**code**:Place of occurrence**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:24:00+0800**value**:Home**note**:
> 

Incident occurred along residential frontage



-------

Entry 32 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111133

Resource Observation:

> 

Profile: [RS Observation - Activity at Time of Incident](StructureDefinition-rs-observation-activity-at-incident.md)

**status**: Final**code**:Injury associated activity**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:26:00+0800**value**:Sports

-------

Entry 33 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111134

Resource Observation:

> 

Profile: [RS Observation - Safety Accessories](StructureDefinition-rs-observation-safety-accessories.md)

**status**: Final**code**:Safety precautions (procedure)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:58:00+0800**value**:Seatbelt

-------

Entry 34 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111135

Resource Observation:

> 

Profile: [RS Observation - Triage Priority](StructureDefinition-rs-observation-triage-priority.md)

**status**: Final**code**:Triage index (assessment scale)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:00:00+0800**value**:Yellow

-------

Entry 35 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111136

Resource Observation:

> 

Profile: [RS Observation - Priority Level (Urgency)](StructureDefinition-rs-observation-urgency.md)

**status**: Final**code**:Priority (attribute)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 17:02:00+0800**value**:Priority 2

-------

Entry 36 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111138

Resource Observation:

> 

Profile: [RS Observation - External Cause: Bites/Stings](StructureDefinition-rs-observation-ec-bites-stings.md)

**status**: Final**code**:Injury caused by animal (disorder)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 15:50:00+0800**value**: true**note**:
> 

Bite from stray dog at roadside



-------

Entry 37 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111139

Resource Observation:

> 

Profile: [RS Observation - External Cause: Burns](StructureDefinition-rs-observation-ec-burns.md)

**status**: Final**code**:Burning due to contact with hot substance (event)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 15:55:00+0800**value**:Fire**note**:
> 

Burns caused by kitchen grease fire



-------

Entry 38 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111140

Resource Observation:

> 

Profile: [RS Observation - External Cause: Chemical/Substance](StructureDefinition-rs-observation-ec-chemical.md)

**status**: Final**code**:Exposure to potentially hazardous substance (event)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 16:00:00+0800**value**: true**note**:
> 

Exposure to industrial bleach



-------

Entry 39 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111141

Resource Observation:

> 

Profile: [RS Observation - External Cause: Contact with Sharp Object](StructureDefinition-rs-observation-ec-sharp-object.md)

**status**: Final**code**:Struck by sharp object**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 16:05:00+0800**value**: true**note**:
> 

Laceration from broken windshield glass



-------

Entry 40 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111142

Resource Observation:

> 

Profile: [RS Observation - External Cause: Drowning](StructureDefinition-rs-observation-ec-drowning.md)

**status**: Final**code**:Drowning (event)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 16:10:00+0800**value**:River**note**:
> 

Vehicle submerged in flooded underpass



-------

Entry 41 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111143

Resource Observation:

> 

Profile: [RS Observation - External Cause: Exposure to Forces of Nature](StructureDefinition-rs-observation-ec-forces-of-nature.md)

**status**: Final**code**:Environmental event**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 16:12:00+0800**value**: true

-------

Entry 42 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111144

Resource Observation:

> 

Profile: [RS Observation - External Cause: Fall](StructureDefinition-rs-observation-ec-fall.md)

**status**: Final**code**:Fall (event)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 16:14:00+0800**value**: true**note**:
> 

Slipped on oil at crash site



-------

Entry 43 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111145

Resource Observation:

> 

Profile: [RS Observation - External Cause: Firecracker](StructureDefinition-rs-observation-ec-firecracker.md)

**status**: Final**code**:Accident caused by fireworks**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 16:16:00+0800**value**: true**note**:
> 

Improvised piccolo firecracker



-------

Entry 44 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111146

Resource Observation:

> 

Profile: [RS Observation - External Cause: Gunshot](StructureDefinition-rs-observation-ec-gunshot.md)

**status**: Final**code**:Struck by firearm discharge**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 16:18:00+0800**value**: true**note**:
> 

Handgun involved in altercation



-------

Entry 45 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111147

Resource Observation:

> 

Profile: [RS Observation - External Cause: Hanging/Strangulation](StructureDefinition-rs-observation-ec-hanging-strangulation.md)

**status**: Final**code**:Asphyxia by strangulation**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 16:20:00+0800**value**: true

-------

Entry 46 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111148

Resource Observation:

> 

Profile: [RS Observation - External Cause: Mauling/Assault](StructureDefinition-rs-observation-ec-mauling-assault.md)

**status**: Final**code**:Assault**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 16:22:00+0800**value**: true

-------

Entry 47 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111149

Resource Observation:

> 

Profile: [RS Observation - External Cause: Sexual Assault/Abuse/Rape (Alleged)](StructureDefinition-rs-observation-ec-sexual-assault.md)

**status**: Final**code**:Sexual assault**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 16:24:00+0800**value**: true

-------

Entry 48 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111150

Resource Observation:

> 

Profile: [RS Observation - External Cause: Other](StructureDefinition-rs-observation-ec-other.md)

**status**: Final**code**:Traumatic event**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-example-patient.md)**encounter**:[Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-example-encounter.md)**effective**: 2025-10-31 16:28:00+0800**value**: true**note**:
> 

Falling debris from construction site



-------

Entry 49 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111151

Resource DocumentReference:

> 

Profile: [RS DocumentReference (Evidence)](StructureDefinition-rs-document-reference.md)

**status**: Current**type**:Document image**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-bundle-example-patient.md)
> **context**[Encounter: identifier = Incident number: INC-2025-0102,Patient hospital visit number (observable entity): HCN-2025-1120; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 15:18:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-bundle-example-encounter.md)

> **content**

### Attachments

| | | | |
| :--- | :--- | :--- | :--- |
| - | **ContentType** | **Url** | **Title** |
| * | image/jpeg | [https://example.org/fhir/Binary/ems-crash-photo](https://example.org/fhir/Binary/ems-crash-photo) | Intersection scene photo |



-------

Entry 50 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111152

Resource ServiceRequest:

> 

Profile: [RS ServiceRequest](StructureDefinition-rs-service-request.md)

**status**: Revoked**intent**: Plan**code**: No display for ServiceRequest.code (concept: )**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-bundle-example-patient.md)**encounter**:[Encounter: identifier = Incident number: INC-2025-0102,Patient hospital visit number (observable entity): HCN-2025-1120; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 15:18:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-bundle-example-encounter.md)**occurrence**: 2025-10-31 15:50:00+0800**supportingInfo**:
* No display for ServiceRequest.supportingInfo (reference: ->Organization MetroCare EMS)
* No display for ServiceRequest.supportingInfo (reference: ->Practitioner Maria Cristina Santos (official))

-------

Entry 51 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111153

Resource Procedure:

> 

Profile: [RS Procedure](StructureDefinition-rs-procedure.md)

**status**: Completed**code**:Patient education (procedure)**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-bundle-example-patient.md)**encounter**:[Encounter: identifier = Incident number: INC-2025-0102,Patient hospital visit number (observable entity): HCN-2025-1120; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 15:18:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-bundle-example-encounter.md)

### Performers

| | |
| :--- | :--- |
| - | **Actor** |
| * | [Practitioner Joel Rivera (official)](Practitioner-rs-bundle-example-practitioner-teamlead.md) |

**note**:
> 

Discussed signs of delayed chest trauma and when to return to ER.



-------

Entry 52 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111154

Resource Procedure:

> 

Profile: [RS Procedure - Transport Coordination](StructureDefinition-rs-procedure-transport-coordination.md)

**status**: Completed**code**:Was Transport Coordinated with Receiving Hospital?**subject**:[Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01](Patient-rs-bundle-example-patient.md)**encounter**:[Encounter: identifier = Incident number: INC-2025-0102,Patient hospital visit number (observable entity): HCN-2025-1120; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 15:18:00+0800 --> 2025-10-31 16:30:00+0800](Encounter-rs-bundle-example-encounter.md)**note**:
> 

Coordination established with ER charge nurse prior to departure.



-------

Entry 53 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111155

Resource Organization:

> 

Profile: [RS Organization](StructureDefinition-rs-organization.md)

**identifier**:[DohNhfrCode](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/NamingSystem-doh-nhfr-code-ns.html)/MC-EMS-0001**active**: true**name**: MetroCare EMS

### Contacts

| | | |
| :--- | :--- | :--- |
| - | **Telecom** | **Address** |
| * | [+63-917-555-0100](tel:+63-917-555-0100) | 123 Rescue Avenue Makati City NCR 1226 PH (work) |


-------

Entry 54 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111156

Resource Practitioner:

> 

Profile: [PH Core Practitioner](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-practitioner.html)

**name**: Maria Cristina Santos (Official)**telecom**:[+63-917-555-0101](tel:+63-917-555-0101)

-------

Entry 55 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111157

Resource Practitioner:

> 

Profile: [PH Core Practitioner](https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-practitioner.html)

**name**: Joel Rivera (Official)**telecom**:[+63-917-555-0155](tel:+63-917-555-0155)

-------

Entry 56 - fullUrl = urn:uuid:11111111-1111-1111-1111-111111111159

Resource Location:

> 

Profile: [RS Service Location](StructureDefinition-rs-location-service.md)

**name**: DOH Central ER**type**:Emergency room**address**: San Lazaro Compound, Rizal Avenue Manila NCR 1003 PH



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "rs-bundle-example-bundle-oneiss",
  "meta" : {
    "profile" : [
      "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-bundle-oneiss"
    ]
  },
  "identifier" : {
    "system" : "urn:fdc:roadsafetyph.doh.gov.ph:bundle",
    "value" : "ONEISS-20251031-001"
  },
  "type" : "transaction",
  "timestamp" : "2025-11-01T10:05:00+08:00",
  "entry" : [
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111102",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "rs-example-patient",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_rs-example-patient\"> </a>RS-Example Patient: Thomas Niccolo Filamor Reyes, male, born 1990-01-01. Address: 123 Sampaloc Street, Manila 1008, PH. Phone: +63-912-345-6789; Email: thomas.reyes@example.com</div>"
        },
        "extension" : [
          {
            "url" : "urn://example.com/ph-core/fhir/StructureDefinition/indigenous-people",
            "valueBoolean" : false
          }
        ],
        "active" : true,
        "name" : [
          {
            "use" : "official",
            "family" : "Reyes",
            "given" : ["Thomas Niccolo", "Filamor"]
          }
        ],
        "telecom" : [
          {
            "system" : "phone",
            "value" : "+63-912-345-6789",
            "use" : "mobile"
          },
          {
            "system" : "email",
            "value" : "thomas.reyes@example.com",
            "use" : "home"
          }
        ],
        "gender" : "male",
        "birthDate" : "1990-01-01",
        "address" : [
          {
            "extension" : [
              {
                "url" : "urn://example.com/ph-core/fhir/StructureDefinition/province",
                "valueCoding" : {
                  "system" : "urn://example.com/ph-core/fhir/CodeSystem/PSGC",
                  "code" : "0402100000",
                  "display" : "Cavite"
                }
              },
              {
                "url" : "urn://example.com/ph-core/fhir/StructureDefinition/city-municipality",
                "valueCoding" : {
                  "system" : "urn://example.com/ph-core/fhir/CodeSystem/PSGC",
                  "code" : "1380100000",
                  "display" : "City of Caloocan"
                }
              },
              {
                "url" : "urn://example.com/ph-core/fhir/StructureDefinition/barangay",
                "valueCoding" : {
                  "system" : "urn://example.com/ph-core/fhir/CodeSystem/PSGC",
                  "code" : "1380100001",
                  "display" : "Barangay 1"
                }
              }
            ],
            "use" : "home",
            "line" : ["123 Sampaloc Street"],
            "city" : "Manila",
            "postalCode" : "1008",
            "country" : "PH"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111103",
      "resource" : {
        "resourceType" : "Encounter",
        "id" : "rs-example-encounter",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-encounter"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_rs-example-encounter\"> </a>Example RS Encounter for rs-example-patient covering an ER visit on 2025-10-31 following a vehicular incident.</div>"
        },
        "extension" : [
          {
            "url" : "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-encounter-vehicle-used",
            "valueCodeableConcept" : {
              "text" : "Ambulance RS-Unit-02 (Type II van)"
            }
          },
          {
            "url" : "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-encounter-vehicle-used",
            "valueCodeableConcept" : {
              "text" : "Back-up Ambulance RS-Unit-05 (Type I)"
            }
          }
        ],
        "identifier" : [
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                  "code" : "AN"
                }
              ]
            },
            "system" : "http://www.roadsafetyph.doh.gov.ph/identifier/incident",
            "value" : "INC-2025-0007"
          },
          {
            "type" : {
              "coding" : [
                {
                  "system" : "http://snomed.info/sct",
                  "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
                  "code" : "722248002",
                  "display" : "Patient hospital visit number (observable entity)"
                }
              ]
            },
            "system" : "http://www.roadsafetyph.doh.gov.ph/identifier/hospital-case",
            "value" : "HCN-2025-0459"
          }
        ],
        "status" : "finished",
        "class" : {
          "system" : "http://loinc.org",
          "code" : "LA10268-3",
          "display" : "ER"
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "participant" : [
          {
            "type" : [
              {
                "coding" : [
                  {
                    "system" : "http://terminology.hl7.org/CodeSystem/v3-ParticipationType",
                    "code" : "REF",
                    "display" : "referrer"
                  }
                ]
              }
            ],
            "individual" : {
              "reference" : "Practitioner/rs-practitioner-receivedby"
            }
          },
          {
            "type" : [
              {
                "coding" : [
                  {
                    "system" : "http://loinc.org",
                    "code" : "90123-1",
                    "display" : "Response team leader name"
                  }
                ]
              }
            ],
            "individual" : {
              "reference" : "Practitioner/rs-practitioner-teamlead"
            }
          },
          {
            "type" : [
              {
                "coding" : [
                  {
                    "system" : "http://snomed.info/sct",
                    "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
                    "code" : "397897005",
                    "display" : "Paramedic (occupation)"
                  }
                ]
              }
            ],
            "individual" : {
              "reference" : "Practitioner/rs-practitioner-treatment"
            }
          }
        ],
        "period" : {
          "start" : "2025-10-31T13:45:00+08:00",
          "end" : "2025-10-31T16:30:00+08:00"
        },
        "hospitalization" : {
          "origin" : {
            "reference" : "Organization/rs-organization-single-ex"
          },
          "destination" : {
            "reference" : "Location/rs-example-service-location-er"
          },
          "dischargeDisposition" : {
            "coding" : [
              {
                "system" : "http://snomed.info/sct",
                "code" : "19712007",
                "display" : "Transferred to another facility/hospital"
              }
            ]
          }
        },
        "location" : [
          {
            "location" : {
              "reference" : "Location/rs-example-incident-location"
            }
          },
          {
            "location" : {
              "reference" : "Location/rs-example-service-location-er"
            }
          }
        ],
        "serviceProvider" : {
          "reference" : "Organization/rs-organization-single-ex"
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111104",
      "resource" : {
        "resourceType" : "Condition",
        "id" : "rs-bundle-example-condition-initial-impression",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-condition-initial-impression"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_rs-bundle-example-condition-initial-impression\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition rs-bundle-example-condition-initial-impression</b></p><a name=\"rs-bundle-example-condition-initial-impression\"> </a><a name=\"hcrs-bundle-example-condition-initial-impression\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-condition-initial-impression.html\">RS Condition — Initial Impression</a></p></div><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status provisional}\">Provisional</span></p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 148006}\">Preliminary diagnosis</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 125605004}\">Injury of multiple body regions (disorder)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>onset</b>: 2025-10-31 15:55:00+0800</p><p><b>note</b>: </p><blockquote><div><p>Polytrauma following multi-vehicle collision; hemodynamics stabilised upon arrival.</p>\n</div></blockquote></div>"
        },
        "clinicalStatus" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
              "code" : "active"
            }
          ]
        },
        "verificationStatus" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
              "code" : "provisional"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://snomed.info/sct",
                "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
                "code" : "148006",
                "display" : "Preliminary diagnosis"
              }
            ]
          }
        ],
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "125605004",
              "display" : "Injury of multiple body regions (disorder)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "onsetDateTime" : "2025-10-31T15:55:00+08:00",
        "note" : [
          {
            "text" : "Polytrauma following multi-vehicle collision; hemodynamics stabilised upon arrival."
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111105",
      "resource" : {
        "resourceType" : "Condition",
        "id" : "rs-bundle-example-condition-final-diagnosis",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-condition-final-diagnosis"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Condition_rs-bundle-example-condition-final-diagnosis\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Condition rs-bundle-example-condition-final-diagnosis</b></p><a name=\"rs-bundle-example-condition-final-diagnosis\"> </a><a name=\"hcrs-bundle-example-condition-final-diagnosis\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-condition-final-diagnosis.html\">RS Condition — Final Diagnosis</a></p></div><p><b>clinicalStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-clinical active}\">Active</span></p><p><b>verificationStatus</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/condition-ver-status confirmed}\">Confirmed</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 29718003}\">Closed fracture of shaft of femur (disorder)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>recordedDate</b>: 2025-11-01 09:00:00+0800</p><p><b>note</b>: </p><blockquote><div><p>Closed mid-shaft femur fracture confirmed via radiograph; scheduled for operative fixation.</p>\n</div></blockquote></div>"
        },
        "clinicalStatus" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/condition-clinical",
              "code" : "active"
            }
          ]
        },
        "verificationStatus" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/condition-ver-status",
              "code" : "confirmed"
            }
          ]
        },
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "29718003",
              "display" : "Closed fracture of shaft of femur (disorder)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "recordedDate" : "2025-11-01T09:00:00+08:00",
        "note" : [
          {
            "text" : "Closed mid-shaft femur fracture confirmed via radiograph; scheduled for operative fixation."
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111106",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-risk-factors",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-other-risk-factors"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-risk-factors\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-risk-factors</b></p><a name=\"rs-example-observation-risk-factors\"> </a><a name=\"hcrs-example-observation-risk-factors\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-other-risk-factors.html\">RS Observation - Other Risk Factors</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 80943009}\">Risk factor (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:56:00+0800</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 704197006}\">Alcohol/liquor</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "80943009",
              "display" : "Risk factor (observable entity)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:56:00+08:00",
        "valueCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "704197006",
              "display" : "Alcohol/liquor"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111107",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-blood-alcohol",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-blood-alcohol"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-blood-alcohol\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-blood-alcohol</b></p><a name=\"rs-example-observation-blood-alcohol\"> </a><a name=\"hcrs-example-observation-blood-alcohol\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-blood-alcohol.html\">RS Observation - Blood Alcohol Concentration</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 167009006}\">Blood ethanol measurement (procedure)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:28:00+0800</p><p><b>value</b>: 0.06 g/dL<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codeg/dL = 'g/dL')</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "167009006",
              "display" : "Blood ethanol measurement (procedure)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:28:00+08:00",
        "valueQuantity" : {
          "value" : 0.06,
          "unit" : "g/dL",
          "system" : "http://unitsofmeasure.org",
          "code" : "g/dL"
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111108",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-condition",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-condition-of-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-condition\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-condition</b></p><a name=\"rs-example-observation-condition\"> </a><a name=\"hcrs-example-observation-condition\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-condition-of-patient.html\">RS Observation - Condition of Patient</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 12386002}\">Patient status determination (procedure)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 16:58:00+0800</p><p><b>value</b>: <span title=\"Codes:\">Stable</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "12386002",
              "display" : "Patient status determination (procedure)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T16:58:00+08:00",
        "valueCodeableConcept" : {
          "text" : "Stable"
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111109",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-status-on-arrival",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-status-on-arrival"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-status-on-arrival\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-status-on-arrival</b></p><a name=\"rs-example-observation-status-on-arrival\"> </a><a name=\"hcrs-example-observation-status-on-arrival\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-status-on-arrival.html\">RS Observation - Status on Arrival</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 118223001}\">Patient status finding (finding)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:04:00+0800</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 438949009}\">Alive</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "118223001",
              "display" : "Patient status finding (finding)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:04:00+08:00",
        "valueCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "438949009",
              "display" : "Alive"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111110",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-outcome",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-outcome-release"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-outcome\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-outcome</b></p><a name=\"rs-example-observation-outcome\"> </a><a name=\"hcrs-example-observation-outcome\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-outcome-release.html\">RS Observation - Outcome at Release</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 418138009}\">Patient condition finding (finding)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 16:34:00+0800</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 268910001}\">Improved</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "418138009",
              "display" : "Patient condition finding (finding)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T16:34:00+08:00",
        "valueCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "268910001",
              "display" : "Improved"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111111",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-transferred",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-transferred-from-facility"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-transferred\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-transferred</b></p><a name=\"rs-example-observation-transferred\"> </a><a name=\"hcrs-example-observation-transferred\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-transferred-from-facility.html\">RS Observation - Transferred From Facility</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 74199-1}\">Transferred from another acute care facility [NTDS]</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 16:30:00+0800</p><p><b>value</b>: true</p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "74199-1",
              "display" : "Transferred from another acute care facility [NTDS]"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T16:30:00+08:00",
        "valueBoolean" : true
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111112",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-referred",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-referred-by-facility"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-referred\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-referred</b></p><a name=\"rs-example-observation-referred\"> </a><a name=\"hcrs-example-observation-referred\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-referred-by-facility.html\">RS Observation - Referred By Facility</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 307836003}\">Referral by establishment (procedure)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 16:32:00+0800</p><p><b>value</b>: true</p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "307836003",
              "display" : "Referral by establishment (procedure)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T16:32:00+08:00",
        "valueBoolean" : true
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111113",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-multiple-injuries",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-multiple-injuries"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-multiple-injuries\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-multiple-injuries</b></p><a name=\"rs-example-observation-multiple-injuries\"> </a><a name=\"hcrs-example-observation-multiple-injuries\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-multiple-injuries.html\">RS Observation - Multiple Injuries?</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 262519004}\">Multiple injuries (disorder)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:30:00+0800</p><p><b>value</b>: true</p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "262519004",
              "display" : "Multiple injuries (disorder)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:30:00+08:00",
        "valueBoolean" : true
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111114",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-abrasion",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-abrasion"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-abrasion\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-abrasion</b></p><a name=\"rs-example-observation-abrasion\"> </a><a name=\"hcrs-example-observation-abrasion\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-abrasion.html\">RS Observation - Abrasion</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 399963005}\">Abrasion (disorder)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:32:00+0800</p><p><b>value</b>: true</p><p><b>note</b>: </p><blockquote><div><p>Superficial abrasion on left forearm</p>\n</div></blockquote><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 53120007}\">Arm</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "399963005",
              "display" : "Abrasion (disorder)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:32:00+08:00",
        "valueBoolean" : true,
        "note" : [
          {
            "text" : "Superficial abrasion on left forearm"
          }
        ],
        "bodySite" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "53120007",
              "display" : "Arm"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111115",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-avulsion",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-avulsion"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-avulsion\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-avulsion</b></p><a name=\"rs-example-observation-avulsion\"> </a><a name=\"hcrs-example-observation-avulsion\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-avulsion.html\">RS Observation - Avulsion</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 284554003}\">Avulsion - injury (disorder)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:34:00+0800</p><p><b>value</b>: true</p><p><b>note</b>: </p><blockquote><div><p>Partial nail avulsion on right index finger</p>\n</div></blockquote><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 38856004}\">Hand structure</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "284554003",
              "display" : "Avulsion - injury (disorder)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:34:00+08:00",
        "valueBoolean" : true,
        "note" : [
          {
            "text" : "Partial nail avulsion on right index finger"
          }
        ],
        "bodySite" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "38856004",
              "display" : "Hand structure"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111116",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-nature-burns",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-nature-burns"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-nature-burns\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-nature-burns</b></p><a name=\"rs-example-observation-nature-burns\"> </a><a name=\"hcrs-example-observation-nature-burns\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-nature-burns.html\">RS Observation - External Cause: Burns</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 125666000}\">Burn (disorder)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:36:00+0800</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 77140003}\">1st Degree Burn</span></p><p><b>note</b>: </p><blockquote><div><p>Mild burn on right forearm</p>\n</div></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "125666000",
              "display" : "Burn (disorder)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:36:00+08:00",
        "valueCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "77140003",
              "display" : "1st Degree Burn"
            }
          ]
        },
        "note" : [
          {
            "text" : "Mild burn on right forearm"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111117",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-concussion",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-concussion"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-concussion\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-concussion</b></p><a name=\"rs-example-observation-concussion\"> </a><a name=\"hcrs-example-observation-concussion\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-concussion.html\">RS Observation - Concussion</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 110030002}\">Concussion injury of brain (disorder)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:38:00+0800</p><p><b>value</b>: true</p><p><b>note</b>: </p><blockquote><div><p>Brief loss of consciousness reported</p>\n</div></blockquote><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 69536005}\">Head structure</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "110030002",
              "display" : "Concussion injury of brain (disorder)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:38:00+08:00",
        "valueBoolean" : true,
        "note" : [
          {
            "text" : "Brief loss of consciousness reported"
          }
        ],
        "bodySite" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "69536005",
              "display" : "Head structure"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111118",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-contusion",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-contusion"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-contusion\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-contusion</b></p><a name=\"rs-example-observation-contusion\"> </a><a name=\"hcrs-example-observation-contusion\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-contusion.html\">RS Observation - Contusion</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 125667009}\">Contusion (disorder)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:40:00+0800</p><p><b>value</b>: true</p><p><b>note</b>: </p><blockquote><div><p>Bruising on left thigh</p>\n</div></blockquote><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 61396006}\">Thigh structure</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "125667009",
              "display" : "Contusion (disorder)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:40:00+08:00",
        "valueBoolean" : true,
        "note" : [
          {
            "text" : "Bruising on left thigh"
          }
        ],
        "bodySite" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "61396006",
              "display" : "Thigh structure"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111119",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-fracture",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-fracture"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-fracture\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-fracture</b></p><a name=\"rs-example-observation-fracture\"> </a><a name=\"hcrs-example-observation-fracture\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-fracture.html\">RS Observation - Fracture</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 125605004}\">Fracture of bone (disorder)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:42:00+0800</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 423125000}\">Closed fracture</span></p><p><b>note</b>: </p><blockquote><div><p>Closed fracture of left radius</p>\n</div></blockquote><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 12298006}\">Radius bone structure</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "125605004",
              "display" : "Fracture of bone (disorder)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:42:00+08:00",
        "valueCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "423125000",
              "display" : "Closed fracture"
            }
          ]
        },
        "note" : [
          {
            "text" : "Closed fracture of left radius"
          }
        ],
        "bodySite" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "12298006",
              "display" : "Radius bone structure"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111120",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-open-wound",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-open-wound"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-open-wound\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-open-wound</b></p><a name=\"rs-example-observation-open-wound\"> </a><a name=\"hcrs-example-observation-open-wound\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-open-wound.html\">RS Observation - Open Wound</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 125643001}\">Open wound (disorder)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:44:00+0800</p><p><b>value</b>: <span title=\"Codes:\">Laceration from glass</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 83738005}\">Forearm structure</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "125643001",
              "display" : "Open wound (disorder)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:44:00+08:00",
        "valueCodeableConcept" : {
          "text" : "Laceration from glass"
        },
        "bodySite" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "83738005",
              "display" : "Forearm structure"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111121",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-traumatic-amputation",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-traumatic-amputation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-traumatic-amputation\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-traumatic-amputation</b></p><a name=\"rs-example-observation-traumatic-amputation\"> </a><a name=\"hcrs-example-observation-traumatic-amputation\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-traumatic-amputation.html\">RS Observation - Traumatic Amputation</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 262595009}\">Traumatic amputation (disorder)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:46:00+0800</p><p><b>value</b>: false</p><p><b>note</b>: </p><blockquote><div><p>No amputation observed</p>\n</div></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "262595009",
              "display" : "Traumatic amputation (disorder)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:46:00+08:00",
        "valueBoolean" : false,
        "note" : [
          {
            "text" : "No amputation observed"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111122",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-other-injury",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-other-injury"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-other-injury\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-other-injury</b></p><a name=\"rs-example-observation-other-injury\"> </a><a name=\"hcrs-example-observation-other-injury\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-other-injury.html\">RS Observation - Other Specified Injury</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 417163006}\">Traumatic or non-traumatic injury (disorder)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:48:00+0800</p><p><b>value</b>: <span title=\"Codes:\">Soft tissue swelling on ankle</span></p><p><b>bodySite</b>: <span title=\"Codes:{http://snomed.info/sct 70258002}\">Ankle structure</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "417163006",
              "display" : "Traumatic or non-traumatic injury (disorder)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:48:00+08:00",
        "valueCodeableConcept" : {
          "text" : "Soft tissue swelling on ankle"
        },
        "bodySite" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "70258002",
              "display" : "Ankle structure"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111123",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-injury-datetime",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-injury-datetime"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-injury-datetime\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-injury-datetime</b></p><a name=\"rs-example-observation-injury-datetime\"> </a><a name=\"hcrs-example-observation-injury-datetime\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-injury-datetime.html\">RS Observation - Date/Time of Injury</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 439771001}\">Date of event (observable entity)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:14:00+0800</p><p><b>value</b>: 2025-10-31 15:20:00+0800</p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "439771001",
              "display" : "Date of event (observable entity)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:14:00+08:00",
        "valueDateTime" : "2025-10-31T15:20:00+08:00"
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111124",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-injury-intent",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-injury-intent"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-injury-intent\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-injury-intent</b></p><a name=\"rs-example-observation-injury-intent\"> </a><a name=\"hcrs-example-observation-injury-intent\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-injury-intent.html\">RS Observation - Injury Intent</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 11375-3}\">Injury intent</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 15:45:00+0800</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 242056005}\">Unintentional/Accidental</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "11375-3",
              "display" : "Injury intent"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T15:45:00+08:00",
        "valueCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "242056005",
              "display" : "Unintentional/Accidental"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111125",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-transport-accident",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-transport-vehicular-accident"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-transport-accident\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-transport-accident</b></p><a name=\"rs-example-observation-transport-accident\"> </a><a name=\"hcrs-example-observation-transport-accident\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-transport-vehicular-accident.html\">RS Observation - Transport/Vehicular Accident</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 274215009}\">Transport accident (event)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 16:26:00+0800</p><p><b>value</b>: true</p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "274215009",
              "display" : "Transport accident (event)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T16:26:00+08:00",
        "valueBoolean" : true
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111126",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-mode-transport",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-mode-of-transport"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-mode-transport\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-mode-transport</b></p><a name=\"rs-example-observation-mode-transport\"> </a><a name=\"hcrs-example-observation-mode-transport\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-mode-of-transport.html\">RS Observation - Mode of Transport to Facility</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 74286-6}\">Transport mode to hospital [NTDS]</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:06:00+0800</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 49122002}\">Ambulance</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "74286-6",
              "display" : "Transport mode to hospital [NTDS]"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:06:00+08:00",
        "valueCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "49122002",
              "display" : "Ambulance"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111127",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-collision-vs-noncollision",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-collision-vs-noncollision"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-collision-vs-noncollision\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-collision-vs-noncollision</b></p><a name=\"rs-example-observation-collision-vs-noncollision\"> </a><a name=\"hcrs-example-observation-collision-vs-noncollision\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-collision-vs-noncollision.html\">RS Observation - Collision vs Non-Collision</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://www.roadsafetyph.doh.gov.ph/CodeSystem MVA-COLLISION}\">FOR TRANSPORT/VEHICULAR ACCIDENT ONLY (Collision; Non-Collision)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:16:00+0800</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA7319-2}\">Collision</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://www.roadsafetyph.doh.gov.ph/CodeSystem",
              "version" : "1",
              "code" : "MVA-COLLISION",
              "display" : "FOR TRANSPORT/VEHICULAR ACCIDENT ONLY (Collision; Non-Collision)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:16:00+08:00",
        "valueCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "LA7319-2",
              "display" : "Collision"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111128",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-patients-vehicle",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-patients-vehicle"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-patients-vehicle\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-patients-vehicle</b></p><a name=\"rs-example-observation-patients-vehicle\"> </a><a name=\"hcrs-example-observation-patients-vehicle\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-patients-vehicle.html\">RS Observation - Patient's Vehicle</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://www.roadsafetyph.doh.gov.ph/CodeSystem PATIENTVEHICLE}\">Vehicles Involved: Patient's Vehicle</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:18:00+0800</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 71783008}\">Car</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://www.roadsafetyph.doh.gov.ph/CodeSystem",
              "version" : "1",
              "code" : "PATIENTVEHICLE",
              "display" : "Vehicles Involved: Patient's Vehicle"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:18:00+08:00",
        "valueCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "71783008",
              "display" : "Car"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111129",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-other-vehicle",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-other-vehicle"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-other-vehicle\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-other-vehicle</b></p><a name=\"rs-example-observation-other-vehicle\"> </a><a name=\"hcrs-example-observation-other-vehicle\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-other-vehicle.html\">RS Observation - Other Vehicle/Object Involved</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://www.roadsafetyph.doh.gov.ph/CodeSystem OTHERVEHICLE}\">Other Vehicle/Object Involved (for COLLISION accident ONLY)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:20:00+0800</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 90748009}\">Motorcycle</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://www.roadsafetyph.doh.gov.ph/CodeSystem",
              "version" : "1",
              "code" : "OTHERVEHICLE",
              "display" : "Other Vehicle/Object Involved (for COLLISION accident ONLY)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:20:00+08:00",
        "valueCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "90748009",
              "display" : "Motorcycle"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111130",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-position-of-patient",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-position-of-patient"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-position-of-patient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-position-of-patient</b></p><a name=\"rs-example-observation-position-of-patient\"> </a><a name=\"hcrs-example-observation-position-of-patient\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-position-of-patient.html\">RS Observation - Position of Patient</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://www.roadsafetyph.doh.gov.ph/CodeSystem PATIENTPOSITION}\">Position of Patient</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:22:00+0800</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 32906002}\">Pedestrian</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://www.roadsafetyph.doh.gov.ph/CodeSystem",
              "version" : "1",
              "code" : "PATIENTPOSITION",
              "display" : "Position of Patient"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:22:00+08:00",
        "valueCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "32906002",
              "display" : "Pedestrian"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111131",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-how-many-vehicles",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-how-many-vehicles"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-how-many-vehicles\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-how-many-vehicles</b></p><a name=\"rs-example-observation-how-many-vehicles\"> </a><a name=\"hcrs-example-observation-how-many-vehicles\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-how-many-vehicles.html\">RS Observation - How Many Vehicles Involved</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://www.roadsafetyph.doh.gov.ph/CodeSystem PATIENTVEHICLE}\">Vehicles Involved: Patient's Vehicle</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:12:00+0800</p><p><b>value</b>: 3</p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://www.roadsafetyph.doh.gov.ph/CodeSystem",
              "version" : "1",
              "code" : "PATIENTVEHICLE",
              "display" : "Vehicles Involved: Patient's Vehicle"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:12:00+08:00",
        "valueInteger" : 3
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111132",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-place-of-occurrence",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-place-of-occurrence"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-place-of-occurrence\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-place-of-occurrence</b></p><a name=\"rs-example-observation-place-of-occurrence\"> </a><a name=\"hcrs-example-observation-place-of-occurrence\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-place-of-occurrence.html\">RS Observation - Place of Occurrence</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://www.roadsafetyph.doh.gov.ph/CodeSystem PLACEOCCURRENCE}\">Place of occurrence</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:24:00+0800</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 264362003}\">Home</span></p><p><b>note</b>: </p><blockquote><div><p>Incident occurred along residential frontage</p>\n</div></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://www.roadsafetyph.doh.gov.ph/CodeSystem",
              "version" : "1",
              "code" : "PLACEOCCURRENCE",
              "display" : "Place of occurrence"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:24:00+08:00",
        "valueCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "264362003",
              "display" : "Home"
            }
          ]
        },
        "note" : [
          {
            "text" : "Incident occurred along residential frontage"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111133",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-activity-at-incident",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-activity-at-incident"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-activity-at-incident\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-activity-at-incident</b></p><a name=\"rs-example-observation-activity-at-incident\"> </a><a name=\"hcrs-example-observation-activity-at-incident\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-activity-at-incident.html\">RS Observation - Activity at Time of Incident</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 11372-0}\">Injury associated activity</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:26:00+0800</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 443786003}\">Sports</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "11372-0",
              "display" : "Injury associated activity"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:26:00+08:00",
        "valueCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "443786003",
              "display" : "Sports"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111134",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-safety-accessories",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-safety-accessories"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-safety-accessories\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-safety-accessories</b></p><a name=\"rs-example-observation-safety-accessories\"> </a><a name=\"hcrs-example-observation-safety-accessories\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-safety-accessories.html\">RS Observation - Safety Accessories</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 386812007}\">Safety precautions (procedure)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:58:00+0800</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 60054005}\">Seatbelt</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "386812007",
              "display" : "Safety precautions (procedure)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:58:00+08:00",
        "valueCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "60054005",
              "display" : "Seatbelt"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111135",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-triage",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-triage-priority"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-triage\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-triage</b></p><a name=\"rs-example-observation-triage\"> </a><a name=\"hcrs-example-observation-triage\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-triage-priority.html\">RS Observation - Triage Priority</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 273887006}\">Triage index (assessment scale)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:00:00+0800</p><p><b>value</b>: <span title=\"Codes:\">Yellow</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "273887006",
              "display" : "Triage index (assessment scale)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:00:00+08:00",
        "valueCodeableConcept" : {
          "text" : "Yellow"
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111136",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-urgency",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-urgency"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-urgency\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-urgency</b></p><a name=\"rs-example-observation-urgency\"> </a><a name=\"hcrs-example-observation-urgency\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-urgency.html\">RS Observation - Priority Level (Urgency)</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 260870009}\">Priority (attribute)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 17:02:00+0800</p><p><b>value</b>: <span title=\"Codes:\">Priority 2</span></p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "260870009",
              "display" : "Priority (attribute)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T17:02:00+08:00",
        "valueCodeableConcept" : {
          "text" : "Priority 2"
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111138",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-ec-bites",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-ec-bites-stings"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-ec-bites\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-ec-bites</b></p><a name=\"rs-example-observation-ec-bites\"> </a><a name=\"hcrs-example-observation-ec-bites\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-ec-bites-stings.html\">RS Observation - External Cause: Bites/Stings</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 242651001}\">Injury caused by animal (disorder)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 15:50:00+0800</p><p><b>value</b>: true</p><p><b>note</b>: </p><blockquote><div><p>Bite from stray dog at roadside</p>\n</div></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "242651001",
              "display" : "Injury caused by animal (disorder)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T15:50:00+08:00",
        "valueBoolean" : true,
        "note" : [
          {
            "text" : "Bite from stray dog at roadside"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111139",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-ec-burns",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-ec-burns"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-ec-burns\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-ec-burns</b></p><a name=\"rs-example-observation-ec-burns\"> </a><a name=\"hcrs-example-observation-ec-burns\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-ec-burns.html\">RS Observation - External Cause: Burns</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 242490006}\">Burning due to contact with hot substance (event)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 15:55:00+0800</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 80032004}\">Fire</span></p><p><b>note</b>: </p><blockquote><div><p>Burns caused by kitchen grease fire</p>\n</div></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "242490006",
              "display" : "Burning due to contact with hot substance (event)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T15:55:00+08:00",
        "valueCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "80032004",
              "display" : "Fire"
            }
          ]
        },
        "note" : [
          {
            "text" : "Burns caused by kitchen grease fire"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111140",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-ec-chemical",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-ec-chemical"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-ec-chemical\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-ec-chemical</b></p><a name=\"rs-example-observation-ec-chemical\"> </a><a name=\"hcrs-example-observation-ec-chemical\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-ec-chemical.html\">RS Observation - External Cause: Chemical/Substance</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 133261000119105}\">Exposure to potentially hazardous substance (event)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 16:00:00+0800</p><p><b>value</b>: true</p><p><b>note</b>: </p><blockquote><div><p>Exposure to industrial bleach</p>\n</div></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "133261000119105",
              "display" : "Exposure to potentially hazardous substance (event)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T16:00:00+08:00",
        "valueBoolean" : true,
        "note" : [
          {
            "text" : "Exposure to industrial bleach"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111141",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-ec-sharp",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-ec-sharp-object"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-ec-sharp\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-ec-sharp</b></p><a name=\"rs-example-observation-ec-sharp\"> </a><a name=\"hcrs-example-observation-ec-sharp\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-ec-sharp-object.html\">RS Observation - External Cause: Contact with Sharp Object</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 69129000}\">Struck by sharp object</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 16:05:00+0800</p><p><b>value</b>: true</p><p><b>note</b>: </p><blockquote><div><p>Laceration from broken windshield glass</p>\n</div></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "69129000",
              "display" : "Struck by sharp object"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T16:05:00+08:00",
        "valueBoolean" : true,
        "note" : [
          {
            "text" : "Laceration from broken windshield glass"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111142",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-ec-drowning",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-ec-drowning"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-ec-drowning\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-ec-drowning</b></p><a name=\"rs-example-observation-ec-drowning\"> </a><a name=\"hcrs-example-observation-ec-drowning\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-ec-drowning.html\">RS Observation - External Cause: Drowning</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 40947009}\">Drowning (event)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 16:10:00+0800</p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 420531007}\">River</span></p><p><b>note</b>: </p><blockquote><div><p>Vehicle submerged in flooded underpass</p>\n</div></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "40947009",
              "display" : "Drowning (event)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T16:10:00+08:00",
        "valueCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "420531007",
              "display" : "River"
            }
          ]
        },
        "note" : [
          {
            "text" : "Vehicle submerged in flooded underpass"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111143",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-ec-forces",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-ec-forces-of-nature"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-ec-forces\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-ec-forces</b></p><a name=\"rs-example-observation-ec-forces\"> </a><a name=\"hcrs-example-observation-ec-forces\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-ec-forces-of-nature.html\">RS Observation - External Cause: Exposure to Forces of Nature</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 276746005}\">Environmental event</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 16:12:00+0800</p><p><b>value</b>: true</p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "276746005",
              "display" : "Environmental event"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T16:12:00+08:00",
        "valueBoolean" : true
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111144",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-ec-fall",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-ec-fall"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-ec-fall\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-ec-fall</b></p><a name=\"rs-example-observation-ec-fall\"> </a><a name=\"hcrs-example-observation-ec-fall\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-ec-fall.html\">RS Observation - External Cause: Fall</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 1912002}\">Fall (event)</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 16:14:00+0800</p><p><b>value</b>: true</p><p><b>note</b>: </p><blockquote><div><p>Slipped on oil at crash site</p>\n</div></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "1912002",
              "display" : "Fall (event)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T16:14:00+08:00",
        "valueBoolean" : true,
        "note" : [
          {
            "text" : "Slipped on oil at crash site"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111145",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-ec-firecracker",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-ec-firecracker"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-ec-firecracker\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-ec-firecracker</b></p><a name=\"rs-example-observation-ec-firecracker\"> </a><a name=\"hcrs-example-observation-ec-firecracker\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-ec-firecracker.html\">RS Observation - External Cause: Firecracker</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 218100007}\">Accident caused by fireworks</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 16:16:00+0800</p><p><b>value</b>: true</p><p><b>note</b>: </p><blockquote><div><p>Improvised piccolo firecracker</p>\n</div></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "218100007",
              "display" : "Accident caused by fireworks"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T16:16:00+08:00",
        "valueBoolean" : true,
        "note" : [
          {
            "text" : "Improvised piccolo firecracker"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111146",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-ec-gunshot",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-ec-gunshot"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-ec-gunshot\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-ec-gunshot</b></p><a name=\"rs-example-observation-ec-gunshot\"> </a><a name=\"hcrs-example-observation-ec-gunshot\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-ec-gunshot.html\">RS Observation - External Cause: Gunshot</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 63409001}\">Struck by firearm discharge</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 16:18:00+0800</p><p><b>value</b>: true</p><p><b>note</b>: </p><blockquote><div><p>Handgun involved in altercation</p>\n</div></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "63409001",
              "display" : "Struck by firearm discharge"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T16:18:00+08:00",
        "valueBoolean" : true,
        "note" : [
          {
            "text" : "Handgun involved in altercation"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111147",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-ec-hanging",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-ec-hanging-strangulation"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-ec-hanging\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-ec-hanging</b></p><a name=\"rs-example-observation-ec-hanging\"> </a><a name=\"hcrs-example-observation-ec-hanging\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-ec-hanging-strangulation.html\">RS Observation - External Cause: Hanging/Strangulation</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 212976008}\">Asphyxia by strangulation</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 16:20:00+0800</p><p><b>value</b>: true</p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "212976008",
              "display" : "Asphyxia by strangulation"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T16:20:00+08:00",
        "valueBoolean" : true
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111148",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-ec-mauling",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-ec-mauling-assault"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-ec-mauling\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-ec-mauling</b></p><a name=\"rs-example-observation-ec-mauling\"> </a><a name=\"hcrs-example-observation-ec-mauling\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-ec-mauling-assault.html\">RS Observation - External Cause: Mauling/Assault</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 52684005}\">Assault</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 16:22:00+0800</p><p><b>value</b>: true</p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "52684005",
              "display" : "Assault"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T16:22:00+08:00",
        "valueBoolean" : true
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111149",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-ec-sexual-assault",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-ec-sexual-assault"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-ec-sexual-assault\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-ec-sexual-assault</b></p><a name=\"rs-example-observation-ec-sexual-assault\"> </a><a name=\"hcrs-example-observation-ec-sexual-assault\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-ec-sexual-assault.html\">RS Observation - External Cause: Sexual Assault/Abuse/Rape (Alleged)</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 248110007}\">Sexual assault</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 16:24:00+0800</p><p><b>value</b>: true</p></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "248110007",
              "display" : "Sexual assault"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T16:24:00+08:00",
        "valueBoolean" : true
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111150",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "rs-example-observation-ec-other",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-observation-ec-other"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_rs-example-observation-ec-other\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation rs-example-observation-ec-other</b></p><a name=\"rs-example-observation-ec-other\"> </a><a name=\"hcrs-example-observation-ec-other\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-observation-ec-other.html\">RS Observation - External Cause: Other</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 773760007}\">Traumatic event</span></p><p><b>subject</b>: <a href=\"Patient-rs-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-example-encounter.html\">Encounter: extension = ,; identifier = Account number,Patient hospital visit number (observable entity): HCN-2025-0459; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 13:45:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>effective</b>: 2025-10-31 16:28:00+0800</p><p><b>value</b>: true</p><p><b>note</b>: </p><blockquote><div><p>Falling debris from construction site</p>\n</div></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "773760007",
              "display" : "Traumatic event"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-example-encounter"
        },
        "effectiveDateTime" : "2025-10-31T16:28:00+08:00",
        "valueBoolean" : true,
        "note" : [
          {
            "text" : "Falling debris from construction site"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111151",
      "resource" : {
        "resourceType" : "DocumentReference",
        "id" : "rs-bundle-example-documentreference",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-document-reference"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DocumentReference_rs-bundle-example-documentreference\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference rs-bundle-example-documentreference</b></p><a name=\"rs-bundle-example-documentreference\"> </a><a name=\"hcrs-bundle-example-documentreference\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-document-reference.html\">RS DocumentReference (Evidence)</a></p></div><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Codes:{http://loinc.org 18748-4}\">Document image</span></p><p><b>subject</b>: <a href=\"Patient-rs-bundle-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Url</b></td><td><b>Title</b></td></tr><tr><td style=\"display: none\">*</td><td>image/jpeg</td><td><a href=\"https://example.org/fhir/Binary/ems-crash-photo\">https://example.org/fhir/Binary/ems-crash-photo</a></td><td>Intersection scene photo</td></tr></table><p><b>format</b>: formatcodes: urn:ihe:pcc:dsr:2016 (urn:ihe:pcc:dsr:2016)</p></blockquote><h3>Contexts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Encounter</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Encounter-rs-bundle-example-encounter.html\">Encounter: identifier = Incident number: INC-2025-0102,Patient hospital visit number (observable entity): HCN-2025-1120; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 15:18:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></td></tr></table></div>"
        },
        "status" : "current",
        "type" : {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18748-4",
              "display" : "Document image"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-bundle-example-patient"
        },
        "content" : [
          {
            "attachment" : {
              "contentType" : "image/jpeg",
              "url" : "https://example.org/fhir/Binary/ems-crash-photo",
              "title" : "Intersection scene photo"
            },
            "format" : {
              "system" : "http://terminology.hl7.org/CodeSystem/formatcodes",
              "code" : "urn:ihe:pcc:dsr:2016"
            }
          }
        ],
        "context" : {
          "encounter" : [
            {
              "reference" : "Encounter/rs-bundle-example-encounter"
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111152",
      "resource" : {
        "resourceType" : "ServiceRequest",
        "id" : "rs-bundle-example-service-request",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-service-request"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_rs-bundle-example-service-request\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest rs-bundle-example-service-request</b></p><a name=\"rs-bundle-example-service-request\"> </a><a name=\"hcrs-bundle-example-service-request\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-service-request.html\">RS ServiceRequest</a></p></div><p><b>status</b>: Revoked</p><p><b>intent</b>: Plan</p><p><b>code</b>: <span title=\"Codes:\">Refusal to admit</span></p><p><b>subject</b>: <a href=\"Patient-rs-bundle-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-bundle-example-encounter.html\">Encounter: identifier = Incident number: INC-2025-0102,Patient hospital visit number (observable entity): HCN-2025-1120; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 15:18:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>occurrence</b>: 2025-10-31 15:50:00+0800</p><p><b>supportingInfo</b>: </p><ul><li><a href=\"Organization-rs-bundle-example-organization.html\">Organization MetroCare EMS</a></li><li><a href=\"Practitioner-rs-bundle-example-practitioner-receiver.html\">Practitioner Maria Cristina Santos (official)</a></li></ul></div>"
        },
        "status" : "revoked",
        "intent" : "plan",
        "code" : {
          "text" : "Refusal to admit"
        },
        "subject" : {
          "reference" : "Patient/rs-bundle-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-bundle-example-encounter"
        },
        "occurrenceDateTime" : "2025-10-31T15:50:00+08:00",
        "supportingInfo" : [
          {
            "reference" : "Organization/rs-bundle-example-organization"
          },
          {
            "reference" : "Practitioner/rs-bundle-example-practitioner-receiver"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111153",
      "resource" : {
        "resourceType" : "Procedure",
        "id" : "rs-bundle-example-procedure-education",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-procedure"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_rs-bundle-example-procedure-education\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure rs-bundle-example-procedure-education</b></p><a name=\"rs-bundle-example-procedure-education\"> </a><a name=\"hcrs-bundle-example-procedure-education\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-procedure.html\">RS Procedure</a></p></div><p><b>status</b>: Completed</p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 710818009}\">Patient education (procedure)</span></p><p><b>subject</b>: <a href=\"Patient-rs-bundle-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-bundle-example-encounter.html\">Encounter: identifier = Incident number: INC-2025-0102,Patient hospital visit number (observable entity): HCN-2025-1120; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 15:18:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>performed</b>: 2025-10-31 16:12:00+0800</p><h3>Performers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Actor</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Practitioner-rs-bundle-example-practitioner-teamlead.html\">Practitioner Joel Rivera (official)</a></td></tr></table><p><b>note</b>: </p><blockquote><div><p>Discussed signs of delayed chest trauma and when to return to ER.</p>\n</div></blockquote></div>"
        },
        "status" : "completed",
        "code" : {
          "coding" : [
            {
              "system" : "http://snomed.info/sct",
              "version" : "http://snomed.info/sct/900000000000207008/version/20241001",
              "code" : "710818009",
              "display" : "Patient education (procedure)"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-bundle-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-bundle-example-encounter"
        },
        "performedDateTime" : "2025-10-31T16:12:00+08:00",
        "performer" : [
          {
            "actor" : {
              "reference" : "Practitioner/rs-bundle-example-practitioner-teamlead"
            }
          }
        ],
        "note" : [
          {
            "text" : "Discussed signs of delayed chest trauma and when to return to ER."
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111154",
      "resource" : {
        "resourceType" : "Procedure",
        "id" : "rs-bundle-example-procedure-transport",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-procedure-transport-coordination"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Procedure_rs-bundle-example-procedure-transport\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure rs-bundle-example-procedure-transport</b></p><a name=\"rs-bundle-example-procedure-transport\"> </a><a name=\"hcrs-bundle-example-procedure-transport\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-procedure-transport-coordination.html\">RS Procedure - Transport Coordination</a></p></div><p><b>status</b>: Completed</p><p><b>code</b>: <span title=\"Codes:{http://www.roadsafetyph.doh.gov.ph/CodeSystem COORDINATIONDONE}\">Was Transport Coordinated with Receiving Hospital?</span></p><p><b>subject</b>: <a href=\"Patient-rs-bundle-example-patient.html\">Thomas Niccolo Filamor Reyes (official) Male, DoB: 1990-01-01</a></p><p><b>encounter</b>: <a href=\"Encounter-rs-bundle-example-encounter.html\">Encounter: identifier = Incident number: INC-2025-0102,Patient hospital visit number (observable entity): HCN-2025-1120; status = finished; class = ER (LOINC#LA10268-3); period = 2025-10-31 15:18:00+0800 --&gt; 2025-10-31 16:30:00+0800</a></p><p><b>performed</b>: 2025-10-31 15:35:00+0800</p><p><b>note</b>: </p><blockquote><div><p>Coordination established with ER charge nurse prior to departure.</p>\n</div></blockquote></div>"
        },
        "status" : "completed",
        "code" : {
          "coding" : [
            {
              "system" : "http://www.roadsafetyph.doh.gov.ph/CodeSystem",
              "version" : "1",
              "code" : "COORDINATIONDONE",
              "display" : "Was Transport Coordinated with Receiving Hospital?"
            }
          ]
        },
        "subject" : {
          "reference" : "Patient/rs-bundle-example-patient"
        },
        "encounter" : {
          "reference" : "Encounter/rs-bundle-example-encounter"
        },
        "performedDateTime" : "2025-10-31T15:35:00+08:00",
        "note" : [
          {
            "text" : "Coordination established with ER charge nurse prior to departure."
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111155",
      "resource" : {
        "resourceType" : "Organization",
        "id" : "rs-bundle-example-organization",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-organization"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Organization_rs-bundle-example-organization\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization rs-bundle-example-organization</b></p><a name=\"rs-bundle-example-organization\"> </a><a name=\"hcrs-bundle-example-organization\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-organization.html\">RS Organization</a></p></div><p><b>identifier</b>: <a href=\"https://build.fhir.org/ig/UP-Manila-SILab/ph-core/NamingSystem-doh-nhfr-code-ns.html\" title=\"Health Facility Code (HFC) from the National Health Facility Registry.\">DohNhfrCode</a>/MC-EMS-0001</p><p><b>active</b>: true</p><p><b>name</b>: MetroCare EMS</p><p><b>telecom</b>: <a href=\"tel:+63-917-555-0100\">+63-917-555-0100</a></p><p><b>address</b>: 123 Rescue Avenue Makati City NCR 1226 PH (work)</p></div>"
        },
        "identifier" : [
          {
            "system" : "http://doh.gov.ph/fhir/Identifier/doh-nhfr-code",
            "value" : "MC-EMS-0001"
          }
        ],
        "active" : true,
        "name" : "MetroCare EMS",
        "telecom" : [
          {
            "system" : "phone",
            "value" : "+63-917-555-0100"
          }
        ],
        "address" : [
          {
            "use" : "work",
            "line" : ["123 Rescue Avenue"],
            "city" : "Makati City",
            "state" : "NCR",
            "postalCode" : "1226",
            "country" : "PH"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111156",
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "rs-bundle-example-practitioner-receiver",
        "meta" : {
          "profile" : [
            "urn://example.com/ph-core/fhir/StructureDefinition/ph-core-practitioner"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_rs-bundle-example-practitioner-receiver\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner rs-bundle-example-practitioner-receiver</b></p><a name=\"rs-bundle-example-practitioner-receiver\"> </a><a name=\"hcrs-bundle-example-practitioner-receiver\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-practitioner.html\">PH Core Practitioner</a></p></div><p><b>name</b>: Maria Cristina Santos (Official)</p><p><b>telecom</b>: <a href=\"tel:+63-917-555-0101\">+63-917-555-0101</a></p></div>"
        },
        "name" : [
          {
            "use" : "official",
            "family" : "Santos",
            "given" : ["Maria Cristina"]
          }
        ],
        "telecom" : [
          {
            "system" : "phone",
            "value" : "+63-917-555-0101"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111157",
      "resource" : {
        "resourceType" : "Practitioner",
        "id" : "rs-bundle-example-practitioner-teamlead",
        "meta" : {
          "profile" : [
            "urn://example.com/ph-core/fhir/StructureDefinition/ph-core-practitioner"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Practitioner_rs-bundle-example-practitioner-teamlead\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner rs-bundle-example-practitioner-teamlead</b></p><a name=\"rs-bundle-example-practitioner-teamlead\"> </a><a name=\"hcrs-bundle-example-practitioner-teamlead\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://build.fhir.org/ig/UP-Manila-SILab/ph-core/StructureDefinition-ph-core-practitioner.html\">PH Core Practitioner</a></p></div><p><b>name</b>: Joel Rivera (Official)</p><p><b>telecom</b>: <a href=\"tel:+63-917-555-0155\">+63-917-555-0155</a></p></div>"
        },
        "name" : [
          {
            "use" : "official",
            "family" : "Rivera",
            "given" : ["Joel"]
          }
        ],
        "telecom" : [
          {
            "system" : "phone",
            "value" : "+63-917-555-0155"
          }
        ]
      }
    },
    {
      "fullUrl" : "urn:uuid:11111111-1111-1111-1111-111111111159",
      "resource" : {
        "resourceType" : "Location",
        "id" : "rs-bundle-example-service-location",
        "meta" : {
          "profile" : [
            "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-location-service"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Location_rs-bundle-example-service-location\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Location rs-bundle-example-service-location</b></p><a name=\"rs-bundle-example-service-location\"> </a><a name=\"hcrs-bundle-example-service-location\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-rs-location-service.html\">RS Service Location</a></p></div><p><b>name</b>: DOH Central ER</p><p><b>type</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-ServiceDeliveryLocationRoleType ER}\">Emergency room</span></p><p><b>address</b>: San Lazaro Compound, Rizal Avenue Manila NCR 1003 PH </p></div>"
        },
        "name" : "DOH Central ER",
        "type" : [
          {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/v3-ServiceDeliveryLocationRoleType",
                "code" : "ER",
                "display" : "Emergency room"
              }
            ]
          }
        ],
        "address" : {
          "line" : ["San Lazaro Compound, Rizal Avenue"],
          "city" : "Manila",
          "state" : "NCR",
          "postalCode" : "1003",
          "country" : "PH"
        }
      }
    }
  ]
}

```
