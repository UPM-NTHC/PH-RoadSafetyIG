# Home - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/ImplementationGuide/example.fhir.ph.roadsafety | *Version*:0.1.0 |
| Draft as of 2025-10-09 | *Computable Name*:PHRoadSafetyIG |

# Draft PH Road Safety Implementation Guide

> **Project Status: In Development**
This Implementation Guide is under active development and is not yet available for public or production use. Content, data models, and implementation details are subject to change.

-------

## Overview

**Draft PH Road Safety Implementation Guide** is a FHIR Implementation Guide for road safety and health information in the Philippines. This project is led by the UP Manila - National Telehealth Center - National Insitutes of Health - [Standards and Interoperability Lab Philippines (SIL-PH)](https://github.com/UPM-NTHC/PH-RoadSafetyIG) Project in partnership with the Department of Health and a broad coalition of government, academic, health, and technology stakeholders.

This guide follows the [WHO SMART Guidelines](https://www.who.int/teams/digital-health-and-innovation/smart-guidelines) framework for digital health standards. The Draft PH Road Safety Implementation Guide (IG) represents the **Level 3 (L3) "Machine Readable"** artifact in the SMART Guidelines process, translating validated workflows and a Minimum Data Set (MDS) into interoperable HL7 FHIR R4 specifications.

-------

### Project Context

Road-traffic injuries are among the most preventable yet under-reported public health threats in the Philippines. Data is fragmented across paper forms, stand-alone apps, and ad-hoc spreadsheets, creating critical blind spots for policymakers, emergency responders, and families. The Draft PH Road Safety IG aims to close these gaps by defining a consensus-driven MDS and mapping it to HL7 FHIR R4 resources, enabling interoperable, machine-readable data exchange nationwide.

This IG is grounded in a series of project-led co-design workshops and feedback sessions (2025), which brought together over 30 stakeholders from emergency medical services, traffic management, hospitals, local government units, and relevant agencies. The resulting guide is operationally validated and designed to support both national reporting and local clinical needs.

-------

### Publisher and Contact

* **Publisher:** UP Manila SILab
* **Canonical:** [https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG](https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG)
* **Version:** 0.1.0 (Draft, CI Build)
* **Contact:** [PH Road Safety IG Maintainers](https://github.com/UPM-NTHC/PH-RoadSafetyIG)

-------

### Documentation

* For technical documentation, installation, build instructions, and modeling standards, see the [GitHub Wiki](https://github.com/UPM-NTHC/PH-RoadSafetyIG/wiki).
* This Implementation Guide and its Minimum Data Set are still being finalized and validated. For questions, refer to the wiki or contact the project team.

-------

This publication includes IP covered under the following statements.

* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.5.0/CodeSystem-ISO3166Part1.html): [ActivityCS](CodeSystem-activity-cs.md), [ActivityVS](ValueSet-activity-vs.md)...Show 96 more,[AgeUnitsVS](ValueSet-age-units-vs.md),[CauseOfCrashCS](CodeSystem-cause-of-crash-cs.md),[CauseOfCrashFileTypeVS](ValueSet-cause-of-crash-file-type-vs.md),[CauseOfCrashVS](ValueSet-cause-of-crash-vs.md),[CauseOfRoadCrash](StructureDefinition-cause-of-road-crash.md),[CollisionTypeCS](CodeSystem-collision-type-cs.md),[CollisionTypeVS](ValueSet-collision-type-vs.md),[CoordinationVS](ValueSet-coordination.md),[EDAvailability](StructureDefinition-ed-availability.md),[ExternalCauseCS](CodeSystem-external-cause-cs.md),[ExternalCauseDetailExt](StructureDefinition-external-cause-detail-ext.md),[ExternalCauseVS](ValueSet-external-cause-vs.md),[FirstAidGiven](StructureDefinition-first-aid-given.md),[FirstAidVS](ValueSet-first-aid.md),[HospitalCaseNo](NamingSystem-hospital-case-no-ns.md),[HospitalPatientID](NamingSystem-hospital-patient-id-ns.md),[IncidentNo](NamingSystem-IncidentNoNS.md),[InjuryNatureCS](CodeSystem-injury-nature-cs.md),[InjuryNatureVS](ValueSet-injury-nature-vs.md),[InterventionVS](ValueSet-intervention.md),[MDSRoadSafety](StructureDefinition-PH-RoadSafetyLogicalModel.md),[MDSRoadSafety2FHIR](ConceptMap-MDSRoadSafety2FHIR.md),[ModeOfTransportCS](CodeSystem-mode-of-transport-cs.md),[ModeOfTransportVS](ValueSet-mode-of-transport-vs.md),[NHFR](NamingSystem-hospital-registry-id-ns.md),[OutcomeCS](CodeSystem-outcome-cs.md),[OutcomeVS](ValueSet-outcome-vs.md),[PHCoreOccupation](StructureDefinition-ph-core-occupation.md),[PHRoadSafetyIG](index.md),[PartyAtFault](StructureDefinition-party-at-fault.md),[PartyAtFaultCS](CodeSystem-party-at-fault-cs.md),[PartyAtFaultVS](ValueSet-party-at-fault-vs.md),[PlaceOccCS](CodeSystem-place-occ-cs.md),[PlaceOccVS](ValueSet-place-occ-vs.md),[PriorityCS](CodeSystem-priority-cs.md),[PriorityVS](ValueSet-priority-vs.md),[PsychosocialProcedureVS](ValueSet-psychosocial-procedure.md),[RSAVPUVS](ValueSet-RS-AVPU-VS.md),[RSAllergyIntolerance](StructureDefinition-RS-Allergyintolerance.md),[RSBreathSoundsVS](ValueSet-RS-BreathSounds-VS.md),[RSClaim](StructureDefinition-RS-Claim.md),[RSCollisionModeVS](ValueSet-RS-CollisionMode-VS.md),[RSCondition](StructureDefinition-RS-Condition.md),[RSConditionOfPatientVS](ValueSet-RS-ConditionOfPatient-VS.md),[RSCyanosisVS](ValueSet-RS-Cyanosis-VS.md),[RSDocumentReference](StructureDefinition-RS-Documentreference.md),[RSDrowningWaterBodyVS](ValueSet-RS-DrowningWaterBody-VS.md),[RSEncounter](StructureDefinition-RS-Encounter.md),[RSGCSEyesVS](ValueSet-RS-GCSEyes-VS.md),[RSGCSMotorVS](ValueSet-RS-GCSMotor-VS.md),[RSGCSVerbalVS](ValueSet-RS-GCSVerbal-VS.md),[RSHealthcareService](StructureDefinition-RS-HealthcareService.md),[RSHospitalCategoryVS](ValueSet-rs-hospital-category.md),[RSInjuryIntentVS](ValueSet-RS-InjuryIntent-VS.md),[RSInjuryTypeVS](ValueSet-RS-InjuryType-VS.md),[RSMedicationStatement](StructureDefinition-RS-Medicationstatement.md),[RSObservation](StructureDefinition-RS-Observation.md),[RSOtherVehicleObjectVS](ValueSet-RS-OtherVehicleObject-VS.md),[RSPatient](StructureDefinition-RS-Patient.md),[RSPatientAge](StructureDefinition-rs-patient-age.md),[RSPatientPositionVS](ValueSet-RS-PatientPosition-VS.md),[RSProcedure](StructureDefinition-RS-Procedure.md),[RSProcedureVS](ValueSet-rs-procedure.md),[RSPulseQualityVS](ValueSet-RS-PulseQuality-VS.md),[RSPulseRhythmVS](ValueSet-RS-PulseRhythm-VS.md),[RSPupilsVS](ValueSet-RS-Pupils-VS.md),[RSQuestionnaire](StructureDefinition-RS-Questionnaire.md),[RSRespiratoryRhythmVS](ValueSet-RS-RespiratoryRhythm-VS.md),[RSRiskFactorsVS](ValueSet-RS-RiskFactors-VS.md),[RSSafetyAccessoriesVS](ValueSet-RS-SafetyAccessories-VS.md),[RSServiceRequest](StructureDefinition-RS-Servicerequest.md),[RSStatusOnArrivalVS](ValueSet-RS-StatusOnArrival-VS.md),[RSTask](StructureDefinition-RS-task.md),[RSTaskStatusCS](CodeSystem-rs-task-status-cs.md),[RSTaskStatusVS](ValueSet-rs-task-status.md),[RSTriageCategoryVS](ValueSet-RS-TriageCategory-VS.md),[RSUrgencyLevelVS](ValueSet-RS-UrgencyLevel-VS.md),[ReportFormReceived](StructureDefinition-report-form-received.md),[ReportFormReceivedCS](CodeSystem-report-form-received-cs.md),[ReportFormReceivedVS](ValueSet-report-form-received-vs.md),[RoadNetworkFileTypeCS](CodeSystem-road-network-file-type-cs.md),[RoadNetworkFileTypeVS](ValueSet-road-network-file-type-vs.md),[RoadNetworkShapeFile](StructureDefinition-road-network-shapefile.md),[SafetyNotesExt](StructureDefinition-safety-notes-ext.md),[SuppliesUsed](StructureDefinition-supplies-used.md),[TrafficIncidentManagement](StructureDefinition-traffic-incident-management.md),[TranspoCoordination](StructureDefinition-transpo-coordination.md),[TransportDetailsExt](StructureDefinition-transport-details-ext.md),[VehicleCondition](StructureDefinition-vehicle-condition.md),[VehicleConditionCS](CodeSystem-vehicle-condition-cs.md),[VehicleConditionVS](ValueSet-vehicle-condition-vs.md),[VehicleList](StructureDefinition-vehicle-list-ext.md),[VehicleTypeCS](CodeSystem-vehicle-types.md),[VehicleTypeVS](ValueSet-vs-rs-vehicle-type.md),[VehicleUsed](StructureDefinition-vehicle-used.md)and[VitalSignsQuestionnaire](Questionnaire-VitalSignsQuestionnaire.md)


* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-ucum.html): [AgeUnitsVS](ValueSet-age-units-vs.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html): [ModeOfTransportVS](ValueSet-mode-of-transport-vs.md), [RSGCSEyesVS](ValueSet-RS-GCSEyes-VS.md), [RSGCSMotorVS](ValueSet-RS-GCSMotor-VS.md), [RSGCSVerbalVS](ValueSet-RS-GCSVerbal-VS.md) and [RSObservation](StructureDefinition-RS-Observation.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [CoordinationVS](ValueSet-coordination.md), [Encounter/road-safety-encounter-example](Encounter-road-safety-encounter-example.md)...Show 24 more,[ExternalCauseVS](ValueSet-external-cause-vs.md),[FirstAidGiven](StructureDefinition-first-aid-given.md),[FirstAidVS](ValueSet-first-aid.md),[InterventionVS](ValueSet-intervention.md),[OutcomeVS](ValueSet-outcome-vs.md),[PsychosocialProcedureVS](ValueSet-psychosocial-procedure.md),[RSAVPUVS](ValueSet-RS-AVPU-VS.md),[RSBreathSoundsVS](ValueSet-RS-BreathSounds-VS.md),[RSConditionOfPatientVS](ValueSet-RS-ConditionOfPatient-VS.md),[RSCyanosisVS](ValueSet-RS-Cyanosis-VS.md),[RSDrowningWaterBodyVS](ValueSet-RS-DrowningWaterBody-VS.md),[RSHealthcareService](StructureDefinition-RS-HealthcareService.md),[RSHospitalCategoryVS](ValueSet-rs-hospital-category.md),[RSInjuryIntentVS](ValueSet-RS-InjuryIntent-VS.md),[RSInjuryTypeVS](ValueSet-RS-InjuryType-VS.md),[RSObservation](StructureDefinition-RS-Observation.md),[RSProcedure](StructureDefinition-RS-Procedure.md),[RSProcedureVS](ValueSet-rs-procedure.md),[RSPulseQualityVS](ValueSet-RS-PulseQuality-VS.md),[RSPulseRhythmVS](ValueSet-RS-PulseRhythm-VS.md),[RSPupilsVS](ValueSet-RS-Pupils-VS.md),[RSRespiratoryRhythmVS](ValueSet-RS-RespiratoryRhythm-VS.md),[RSStatusOnArrivalVS](ValueSet-RS-StatusOnArrival-VS.md)and[TranspoCoordination](StructureDefinition-transpo-coordination.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [Discharge disposition](http://terminology.hl7.org/6.5.0/CodeSystem-discharge-disposition.html): [Encounter/road-safety-encounter-example](Encounter-road-safety-encounter-example.md)
* [Location type](http://terminology.hl7.org/6.5.0/CodeSystem-location-physical-type.html): [RSEncounter](StructureDefinition-RS-Encounter.md)
* [Organization type](http://terminology.hl7.org/6.5.0/CodeSystem-organization-type.html): [City General Hospital](Organization-hospital-example.md) and [UP Philippine General Hospital](Organization-organization-uppgh.md)
* [ActCode](http://terminology.hl7.org/6.5.0/CodeSystem-v3-ActCode.html): [Encounter/road-safety-encounter-example](Encounter-road-safety-encounter-example.md)
* [ParticipationType](http://terminology.hl7.org/6.5.0/CodeSystem-v3-ParticipationType.html): [Encounter/road-safety-encounter-example](Encounter-road-safety-encounter-example.md) and [RSEncounter](StructureDefinition-RS-Encounter.md)
* [RoleCode](http://terminology.hl7.org/6.5.0/CodeSystem-v3-RoleCode.html): [RSEncounter](StructureDefinition-RS-Encounter.md)





*There are no Global profiles defined*

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (example.fhir.ph.roadsafety.r4)](package.r4.tgz) and [R4B (example.fhir.ph.roadsafety.r4b)](package.r4b.tgz) are available.

