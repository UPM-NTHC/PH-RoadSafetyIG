# Home - DRAFT PH Road Safety Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/ImplementationGuide/example.fhir.ph.roadsafety | *Version*:0.1.0 |
| Draft as of 2025-10-15 | *Computable Name*:PHRoadSafetyIG |

# Draft PH Road Safety Implementation Guide

> **Project Status: In Development**
This Implementation Guide is under active development and is not yet available for public or production use. Content, data models, and implementation details are subject to change.

-------

## Overview

**Draft PH Road Safety Implementation Guide** is a FHIR Implementation Guide for road safety and health information in the Philippines. This project is led by the UP Manila - National Telehealth Center - National Insitutes of Health - [Standards and Interoperability Lab Philippines (SIL-PH)](https://github.com/UPM-NTHC/PH-RoadSafetyIG) Project in partnership with the Department of Health and a broad coalition of government, academic, health, and technology stakeholders.

This guide follows the [WHO SMART Guidelines](https://www.who.int/teams/digital-health-and-innovation/smart-guidelines) framework for digital health standards. The Draft PH Road Safety Implementation Guide (IG) represents the **Level 3 (L3) "Machine Readable"** artifact in the SMART Guidelines process, translating validated workflows and a Minimum Data Set (MDS) into interoperable HL7 FHIR R4 specifications.

-------

### Project Context

Road-traffic injuries are among the most preventable yet under-reported public health threats in the Philippines. Data is fragmented across paper forms, stand-alone apps, and ad-hoc spreadsheets, creating critical blind spots for policymakers, emergency responders, and families. The Draft PH Road Safety IG aims to close these gaps by defining a consensus-driven MDS and mapping it to HL7 FHIR R4 resources, enabling interoperable, machine-readable data exchange nationwide.

This IG is grounded in a series of project-led co-design workshops and feedback sessions (2025), which brought together over 30 stakeholders from emergency medical services, traffic management, hospitals, local government units, and relevant agencies. The resulting guide is operationally validated and designed to support both national reporting and local clinical needs.

-------

### Publisher and Contact

* **Publisher:** UP Manila SILab
* **Canonical:** [https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG](https://build.fhir.org/ig/UP-Manila-SILab/PH-RoadSafetyIG)
* **Version:** 0.1.0 (Draft, CI Build)
* **Contact:** [PH Road Safety IG Maintainers](https://github.com/UPM-NTHC/PH-RoadSafetyIG)

-------

### Documentation

* For technical documentation, installation, build instructions, and modeling standards, see the [GitHub Wiki](https://github.com/UPM-NTHC/PH-RoadSafetyIG/wiki).
* This Implementation Guide and its Minimum Data Set are still being finalized and validated. For questions, refer to the wiki or contact the project team.

-------

This publication includes IP covered under the following statements.

* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.5.0/CodeSystem-ISO3166Part1.html): [MDSRoadSafety](StructureDefinition-PH-RoadSafetyLogicalModel.md), [MDSRoadSafety2FHIR](ConceptMap-MDSRoadSafety2FHIR.md)...Show 84 more,[PHRoadSafetyIG](index.md),[RSAllergyIntolerance](StructureDefinition-RS-AllergyIntolerance.md),[RSClaim](StructureDefinition-RS-Claim.md),[RSCondition](StructureDefinition-RS-Condition.md),[RSDocumentReference](StructureDefinition-RS-DocumentReference.md),[RSEncounter](StructureDefinition-RS-Encounter.md),[RSLocation](StructureDefinition-RS-Location-Incident.md),[RSMedicationStatement](StructureDefinition-RS-MedicationStatement.md),[RSObsAbrasion](StructureDefinition-RS-Observation-abrasion.md),[RSObsActivityAtIncident](StructureDefinition-RS-Observation-activity-at-incident.md),[RSObsAvulsion](StructureDefinition-RS-Observation-avulsion.md),[RSObsBloodPressure](StructureDefinition-RS-Observation-blood-pressure.md),[RSObsBodyTemperature](StructureDefinition-RS-Observation-body-temperature.md),[RSObsBurn1stDegree](StructureDefinition-RS-Observation-burn-1st.md),[RSObsBurn2ndDegree](StructureDefinition-RS-Observation-burn-2nd.md),[RSObsBurn3rdDegree](StructureDefinition-RS-Observation-burn-3rd.md),[RSObsBurn4thDegree](StructureDefinition-RS-Observation-burn-4th.md),[RSObsCallSource](StructureDefinition-RS-Observation-call-source.md),[RSObsCollisionType](StructureDefinition-RS-Observation-collision-type.md),[RSObsCollisionVsNonCollision](StructureDefinition-RS-Observation-collision-vs-noncollision.md),[RSObsConcussion](StructureDefinition-RS-Observation-concussion.md),[RSObsContusion](StructureDefinition-RS-Observation-contusion.md),[RSObsCyanosis](StructureDefinition-RS-Observation-cyanosis.md),[RSObsDateReceived](StructureDefinition-RS-Observation-date-received.md),[RSObsECBitesStings](StructureDefinition-RS-Observation-ec-bites-stings.md),[RSObsECBitesStingsAgent](StructureDefinition-RS-Observation-ec-bites-stings-agent.md),[RSObsECBurns](StructureDefinition-RS-Observation-ec-burns.md),[RSObsECBurnsAgent](StructureDefinition-RS-Observation-ec-burns-agent.md),[RSObsECBurnsOther](StructureDefinition-RS-Observation-ec-burns-other.md),[RSObsECChemical](StructureDefinition-RS-Observation-ec-chemical.md),[RSObsECChemicalAgent](StructureDefinition-RS-Observation-ec-chemical-agent.md),[RSObsECDrowning](StructureDefinition-RS-Observation-ec-drowning.md),[RSObsECDrowningOther](StructureDefinition-RS-Observation-ec-drowning-other.md),[RSObsECDrowningType](StructureDefinition-RS-Observation-ec-drowning-type.md),[RSObsECFall](StructureDefinition-RS-Observation-ec-fall.md),[RSObsECFallSpecifics](StructureDefinition-RS-Observation-ec-fall-specifics.md),[RSObsECFirecracker](StructureDefinition-RS-Observation-ec-firecracker.md),[RSObsECFirecrackerType](StructureDefinition-RS-Observation-ec-firecracker-type.md),[RSObsECForcesOfNature](StructureDefinition-RS-Observation-ec-forces-of-nature.md),[RSObsECGunshot](StructureDefinition-RS-Observation-ec-gunshot.md),[RSObsECGunshotWeapon](StructureDefinition-RS-Observation-ec-gunshot-weapon.md),[RSObsECHangingStrangulation](StructureDefinition-RS-Observation-ec-hanging-strangulation.md),[RSObsECMaulingAssault](StructureDefinition-RS-Observation-ec-mauling-assault.md),[RSObsECOther](StructureDefinition-RS-Observation-ec-other.md),[RSObsECOtherSpecify](StructureDefinition-RS-Observation-ec-other-specify.md),[RSObsECSexualAssault](StructureDefinition-RS-Observation-ec-sexual-assault.md),[RSObsECSharpObject](StructureDefinition-RS-Observation-ec-sharp-object.md),[RSObsECSharpObjectSpecify](StructureDefinition-RS-Observation-ec-sharp-object-specify.md),[RSObsFractureClosed](StructureDefinition-RS-Observation-fracture-closed.md),[RSObsFractureOpen](StructureDefinition-RS-Observation-fracture-open.md),[RSObsGCS](StructureDefinition-RS-Observation-gcs.md),[RSObsHowManyPatients](StructureDefinition-RS-Observation-how-many-patients.md),[RSObsHowManyVehicles](StructureDefinition-RS-Observation-how-many-vehicles.md),[RSObsInjuryDateTime](StructureDefinition-RS-Observation-injury-datetime.md),[RSObsInjuryIntent](StructureDefinition-RS-Observation-injury-intent.md),[RSObsLevelOfConsciousness](StructureDefinition-RS-Observation-level-of-consciousness.md),[RSObsModeOfTransport](StructureDefinition-RS-Observation-mode-of-transport.md),[RSObsMultipleInjuries](StructureDefinition-RS-Observation-multiple-injuries.md),[RSObsOpenWound](StructureDefinition-RS-Observation-open-wound.md),[RSObsOtherInjury](StructureDefinition-RS-Observation-other-injury.md),[RSObsOtherRiskFactors](StructureDefinition-RS-Observation-other-risk-factors.md),[RSObsOtherVehicleInvolved](StructureDefinition-RS-Observation-other-vehicle.md),[RSObsPatientsVehicle](StructureDefinition-RS-Observation-patients-vehicle.md),[RSObsPlaceOfOccurrence](StructureDefinition-RS-Observation-place-of-occurrence.md),[RSObsPositionOfPatient](StructureDefinition-RS-Observation-position-of-patient.md),[RSObsPresenceTrafficInvestigator](StructureDefinition-RS-Observation-traffic-investigator.md),[RSObsPulseRate](StructureDefinition-RS-Observation-pulse-rate.md),[RSObsPupils](StructureDefinition-RS-Observation-pupils.md),[RSObsReportedComplaint](StructureDefinition-RS-Observation-reported-complaint.md),[RSObsRespiratoryRate](StructureDefinition-RS-Observation-respiratory-rate.md),[RSObsSafetyAccessories](StructureDefinition-RS-Observation-safety-accessories.md),[RSObsTimeDepartedScene](StructureDefinition-RS-Observation-time-departed.md),[RSObsTimeEnroute](StructureDefinition-RS-Observation-time-enroute.md),[RSObsTimeHospitalArrival](StructureDefinition-RS-Observation-time-hospital-arrival.md),[RSObsTimeOnScene](StructureDefinition-RS-Observation-time-on-scene.md),[RSObsTimeStationArrival](StructureDefinition-RS-Observation-time-station-arrival.md),[RSObsTransportVehicularFlag](StructureDefinition-RS-Observation-transport-vehicular-flag.md),[RSObsTraumaticAmputation](StructureDefinition-RS-Observation-traumatic-amputation.md),[RSObsTriagePriority](StructureDefinition-RS-Observation-triage-priority.md),[RSObsUrgencyLevel](StructureDefinition-RS-Observation-urgency.md),[RSObservation](StructureDefinition-RS-Observation.md),[RSPatient](StructureDefinition-RS-Patient.md),[RSProcedure](StructureDefinition-RS-Procedure.md)and[RSServiceRequest](StructureDefinition-RS-ServiceRequest.md)





*There are no Global profiles defined*

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (example.fhir.ph.roadsafety.r4)](package.r4.tgz) and [R4B (example.fhir.ph.roadsafety.r4b)](package.r4b.tgz) are available.

