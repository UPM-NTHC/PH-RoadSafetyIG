# RS Incident Location - DRAFT PH Road Safety Implementation Guide v0.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **RS Incident Location**

## Resource Profile: RS Incident Location 

| | |
| :--- | :--- |
| *Official URL*:https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-incident-location-incident | *Version*:0.3.0 |
| Draft as of 2025-11-09 | *Computable Name*:RSIncidentLocation |

 
Location of incident; supports PH-Core address extensions and geolocation. 

**Usages:**

* Use this Profile: [RS Bundle — Minimum Data Set](StructureDefinition-rs-bundle-minimum.md)
* Refer to this Profile: [RS Encounter](StructureDefinition-rs-encounter.md) and [RS HealthcareService](StructureDefinition-rs-healthcare-service.md)
* Examples for this Profile: [EDSA & Ayala Intersection/a>,[EDSA - Ayala Southbound](Location-rs-example-incident-location.md)and[Location/rs-minimum-example-location](Location-rs-minimum-example-location.md)
You can also check for[usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/example.fhir.ph.roadsafety|current/StructureDefinition/rs-incident-location-incident)

### Formal Views of Profile Content

[Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions).
 
Other representations of profile:[CSV](StructureDefinition-rs-incident-location-incident.csv),[Excel](StructureDefinition-rs-incident-location-incident.xlsx),[Schematron](StructureDefinition-rs-incident-location-incident.sch)

](Location-rs-example-incident-location-basic.md)



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "rs-incident-location-incident",
  "url" : "https://build.fhir.org/ig/UPM-NTHC/PH-RoadSafetyIG/StructureDefinition/rs-incident-location-incident",
  "version" : "0.3.0",
  "name" : "RSIncidentLocation",
  "title" : "RS Incident Location",
  "status" : "draft",
  "date" : "2025-11-09T07:15:59+00:00",
  "publisher" : "UP Manila - National Institutes of Health - National Telehealth Center",
  "contact" : [
    {
      "name" : "UP Manila - National Institutes of Health - National Telehealth Center",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://github.com/UPM-NTHC/PH-RoadSafetyIG"
        }
      ]
    },
    {
      "name" : "PH Road Safety IG Repository",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://github.com/UPM-NTHC/PH-RoadSafetyIG"
        }
      ]
    }
  ],
  "description" : "Location of incident; supports PH-Core address extensions and geolocation.",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "PH",
          "display" : "Philippines"
        }
      ]
    }
  ],
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Location",
  "baseDefinition" : "urn://example.com/ph-core/fhir/StructureDefinition/ph-core-location",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Location.name",
        "path" : "Location.name",
        "short" : "Location name",
        "mustSupport" : true
      },
      {
        "id" : "Location.address",
        "path" : "Location.address",
        "short" : "Location address",
        "mustSupport" : true
      },
      {
        "id" : "Location.address.extension",
        "path" : "Location.address.extension",
        "mustSupport" : true
      },
      {
        "id" : "Location.address.line",
        "path" : "Location.address.line",
        "mustSupport" : true
      },
      {
        "id" : "Location.position",
        "path" : "Location.position",
        "mustSupport" : true
      },
      {
        "id" : "Location.position.longitude",
        "path" : "Location.position.longitude",
        "short" : "Longitude",
        "mustSupport" : true
      },
      {
        "id" : "Location.position.latitude",
        "path" : "Location.position.latitude",
        "short" : "Latitude",
        "mustSupport" : true
      }
    ]
  }
}

```
